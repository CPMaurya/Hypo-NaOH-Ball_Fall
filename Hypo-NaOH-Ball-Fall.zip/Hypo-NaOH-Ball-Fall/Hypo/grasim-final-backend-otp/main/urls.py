from django.urls import path, include
from .views import *

urlpatterns = [
    path('dosage/all/', DosageListView.as_view()),
    path('dosage/<int:pk>/', DosageDetailView.as_view()),
    path("export_to_csv/", ExportView.as_view()),
    path("export_to_csv_month/", MonthExportView.as_view()),
    path('login/', LoginView.as_view()),
    path('user/', UserDosageView.as_view()),
    path('export_from_to_csv/', BetweenDateView.as_view()),
    path('push_hypo/', ClientHypoPush.as_view()),
    path('push_hypo_auto/', ClientHypoPushAuto.as_view(), 
    name='client-hypo-push-auto'),
    path('save_target_values/', SaveTargetValueView.as_view(), 
    name='save-target-values')
]