export const BASE_API_URL = "http://192.168.1.104:8000/main";
export const LOGIN_API = "login/";
export const USER_API = "user/";
export const DOSAGE_ALL_API = "dosage/all/";
export const EXPORT_CSV_DAY_API = "export_to_csv/?id";
export const EXPORT_CSV_RANGE_API = "/export_from_to_csv/?end_date=";
export const AUTO_RUN = "push_hypo_auto/"
export const UPDATE_URL = "save_target_values/"
