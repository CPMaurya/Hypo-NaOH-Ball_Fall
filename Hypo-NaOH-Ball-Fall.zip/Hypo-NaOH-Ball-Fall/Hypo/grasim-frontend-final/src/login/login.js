import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import './login.css';
import grasim from './images/grasin.png'
import { useNavigate } from "react-router-dom";
import { useState } from 'react';
import axios from "axios";
import { BASE_API_URL, LOGIN_API } from '../constants/api'

function Homepage1() {

    const [email, setemail] = useState("");
    const navigate = useNavigate();

    const navigator = () => {
            axios
            .post(`${BASE_API_URL}/${LOGIN_API}`, {
                
                    email: email,
                
            })
            .then((response) => {
                console.log(response)
                console.log("logged in")
                localStorage.setItem('user_id', JSON.stringify(response.data.id));
                navigate("/run")
            })
            .catch((error) => {
                //console.log("")
                //console.log("error")})
                alert("Error: "+ error)});
    };

    const updateemail = (event) => {
        setemail(event.target.value);
    };
    
    return (
        <>
            <div className='row l_back_img'>
                <div className='row l_tb'>
                    <div className='lll'>
                        <div className='row l_login_tab'>
                            <div className='flex items-center gap-8 ml-4'>
                                <img className='h-14 w-20 object-cover' src={grasim}></img>
                                <div className='text-5xl text-white'>Log In</div>
                            </div>
                        
                               
                            
                        </div>
                    </div>
                </div>
                {
                    <div className='row l_login_box2'>
                        <div className='row'>
                            <div className=''>
                                <div className='text-2xl text-gray-600 mb-2'>User ID</div>
                            </div>

                            <input
                                className='ml-3 rounded-lg mb-4 py-2'
                                defaultValue={email}
                                type="text"
                                value={email}
                                onChange={updateemail}
                                placeholder="Please enter your User ID"
                            />

                        </div>
  
                        <div className='row '>
                            <div className='col-4'>
                                <div className='l_enter_text'></div>
                            </div>

                            <div className='col-6 l_sent_otp1' onClick={() => navigator()}>
                                <div className='l_login_otp_text' ><div>Enter</div></div>
                            </div>
                        </div>
                    </div>
                }

                <div className='row l_b1'>
                    <div className='l_ripik'>
                        Powered by Ripik.ai
                    </div>
                </div>
            </div>
        </>
    )
}

export default Homepage1;