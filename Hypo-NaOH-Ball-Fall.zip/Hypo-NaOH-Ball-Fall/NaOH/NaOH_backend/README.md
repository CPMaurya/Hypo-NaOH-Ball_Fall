# Grasim Ball-fall tool

## Execution : 
- python manage.py runserver

