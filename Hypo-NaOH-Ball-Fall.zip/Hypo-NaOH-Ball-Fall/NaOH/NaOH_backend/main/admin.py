from django.contrib import admin
from .models import *

class DosagesNaOHRecommenderAdmin(admin.ModelAdmin):
    list_display = (
        'user',
        'Do_Pulp_PH_n_4',
        'NaOH_Dosage_n_3',
        'H2O2_flow_n_3',
        'VF3_Inlet_Consistency_n_3',
        'VF3_Inlet_Flow_n_3',
        'EOP_Tower_Temperature_n_3',
        'EOP_Tower_Level_n_3',
        'EOP_Viscosity_n_3',
        'EOP_Brightness_n_3',
        'EOP_Target_PH',
        'NaOH_Dosage',
        'NaOH_flow',
        'date',
        'time',
    )

# Register your models here.
admin.site.register(DosagesNaOHRecommender, DosagesNaOHRecommenderAdmin)
admin.site.register(NewUser)