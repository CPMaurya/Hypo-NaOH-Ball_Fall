from django.db import models
from django.utils import timezone
import uuid

# import django
from django.conf import settings
from django.utils.timezone import activate
activate(settings.TIME_ZONE)
from django.contrib import admin
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils.translation import gettext_lazy


class CustomAccountManager(BaseUserManager):
    def create_user(self, email, password, **other_fields):
        other_fields.setdefault("is_active", True)
        if not email:
            raise ValueError(gettext_lazy("You must provide an email"))
        email = self.normalize_email(email)
        user = self.model(email = email, **other_fields)
        user.set_password(password)
        user.save()
        return user
    def create_superuser(self, email, password, **other_fields):
        other_fields.setdefault("is_superuser", True)
        other_fields.setdefault("is_staff", True)
        other_fields.setdefault("is_active", True)
        return self.create_user(email, password, **other_fields)


class NewUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField( gettext_lazy("Email Address"), unique=True, )
    first_name = models.CharField(max_length=150, blank=True)
    username = models.CharField(max_length=150, blank=True, null=True)
    start_Date = models.DateTimeField(default=timezone.now)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    objects = CustomAccountManager()
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    def __str__(self):
        return self.email


class DosagesNaOHRecommender(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(NewUser, on_delete=models.SET_NULL, null=True)
    Do_Pulp_PH_n_4 = models.FloatField(blank=True, null=True)
    NaOH_Dosage_n_3 = models.FloatField(blank=True, null=True)
    H2O2_flow_n_3 = models.FloatField(blank=True, null=True)
    VF3_Inlet_Consistency_n_3 = models.FloatField(blank=True, null=True)
    VF3_Inlet_Flow_n_3 = models.FloatField(blank=True, null=True)
    EOP_Tower_Temperature_n_3 = models.FloatField(blank=True, null=True)
    EOP_Tower_Level_n_3 = models.FloatField(blank=True, null=True)
    EOP_Viscosity_n_3 = models.FloatField(blank=True, null=True)
    EOP_Brightness_n_3 = models.FloatField(blank=True, null=True)
    EOP_Target_PH = models.FloatField(blank=True, null=True)
    NaOH_Dosage = models.FloatField(blank=True, null=True)
    date = models.DateField(default=timezone.now)
    time = models.TimeField(default=timezone.localtime)
    NaOH_flow = models.FloatField(blank=True, null=True)

    class Meta:
        db_table = 'DosagesNaOHRecommender'

    def __str__(self):
        return str(self.date) + "-" + str(self.time) + "-" + str(self.recommendation) 