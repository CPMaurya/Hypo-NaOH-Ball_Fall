from .models import *
from rest_framework import serializers


class DosageCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = DosagesNaOHRecommender
        fields = (
            'user', 'Do_Pulp_PH_n_4', 'NaOH_Dosage_n_3', 'H2O2_flow_n_3', 
            'VF3_Inlet_Consistency_n_3', 'VF3_Inlet_Flow_n_3', 
            'EOP_Tower_Temperature_n_3', 'EOP_Tower_Level_n_3',
            'EOP_Viscosity_n_3', 'EOP_Brightness_n_3', 'EOP_Target_PH', 
            'NaOH_Dosage', 'NaOH_flow',)


class DosageSerializer(serializers.ModelSerializer):
    date = serializers.DateField(format="%d-%m-%y")
    class Meta:
        model = DosagesNaOHRecommender
        fields = "__all__"

    def to_representation(self, instance):
        response = super().to_representation(instance)
        response['time'] = instance.time.strftime("%H:%M:%S") if instance.time else None
        return response

class NewUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewUser
        fields = "__all__"