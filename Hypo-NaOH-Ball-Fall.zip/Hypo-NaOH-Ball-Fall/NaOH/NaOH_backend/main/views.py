from django.http import JsonResponse, HttpResponse
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.permissions import *
from rest_framework.response import Response
from .serializers import *
from .models import *
from braces.views import CsrfExemptMixin
import csv
from django.contrib.auth import authenticate
from django.core.mail import send_mail
from django.conf import settings
from django.db import transaction
from datetime import date, timedelta, datetime
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import pandas as pd
import numpy as np
import pickle
import os
from main.utils import get_data_from_pi, recommend
import copy


class DosageDetailView(CsrfExemptMixin, generics.RetrieveUpdateDestroyAPIView):
    permission_classes = []
    serializer_class = DosageSerializer
    queryset = DosagesNaOHRecommender.objects.all()


class DosageListView(CsrfExemptMixin, generics.ListCreateAPIView):
    permission_classes = []
    serializer_class = DosageCreateSerializer
    queryset = DosagesNaOHRecommender.objects.all()

class ExportView(APIView):
    def get(self, request):
        today_date = date.today()
        print(today_date)
        user_id = request.query_params['id']
        dosage = DosagesNaOHRecommender.objects.filter(user = user_id, date = today_date)
        response = HttpResponse('')
        response['Content-Disposition'] = 'attachment; filename = dosage_all.csv'
        writer = csv.writer(response)
        writer.writerow([
            'Do_Pulp_PH_n_4',
            'NaOH_Dosage_n_3',
            'H2O2_flow_n_3',
            'VF3_Inlet_Consistency_n_3',
            'VF3_Inlet_Flow_n_3',
            'EOP_Tower_Temperature_n_3',
            'EOP_Tower_Level_n_3',
            'EOP_Viscosity_n_3',
            'EOP_Brightness_n_3',
            'EOP_Target_PH',
            'NaOH_Dosage',
            'NaOH_flow',
            'date',
            'time',
        ])
        dosage_fields = dosage.values_list(
            'Do_Pulp_PH_n_4',
            'NaOH_Dosage_n_3',
            'H2O2_flow_n_3',
            'VF3_Inlet_Consistency_n_3',
            'VF3_Inlet_Flow_n_3',
            'EOP_Tower_Temperature_n_3',
            'EOP_Tower_Level_n_3',
            'EOP_Viscosity_n_3',
            'EOP_Brightness_n_3',
            'EOP_Target_PH',
            'NaOH_Dosage',
            'NaOH_flow',
            'date',
            'time',
        )
        for dosage in dosage_fields:
            writer.writerow(dosage)
        return response


class LoginView(APIView):
    def get(self, request):
        email = request.query_params['email']
        print(email)
        otp = int(request.query_params['otp'])
        print(otp)
        user = authenticate(email=email, password=otp)
        if user is not None:
            user_object = NewUser.objects.get(email=email)
            print(user_object)
            user_id = user_object.id
            user_email = user_object.email
            data = {
                'id': user_id,
                'email': user_email,
            }
            return JsonResponse({"message": "verified", "user": data}, status=200)
        else:
            return JsonResponse({"message": "incorrect otp"}, status=200)

    def post(self, request):
        email = request.data['email']
        # def sendotpfinal(email):
        #     otp = int((random.uniform(0, 1))*100000)
        #     # print(otp)
        #     if otp <= 100000 and otp >10000:
        #         otp = f"{otp}"
        #     elif otp <= 10000 and otp >1000:
        #         otp = f"0{otp}"
        #     elif otp <= 1000 and otp >100:
        #         otp = f"00{otp}"
        #     elif otp <= 100 and otp >10:
        #         otp = f"000{otp}"
        #     elif otp <= 10 and otp >1:
        #         otp = f"0000{otp}"
        #     otp = str(otp)
        #     # print(otp)
        #     sendotp(email,otp)
        #     changepassword(email, otp)
        #     return "OTP Sent"
        # foo = sendotpfinal(email)
        try:
            user = NewUser.objects.get(email=email)
            data = {
                "id": user.id,
                "email": user.email,
            }
            return JsonResponse(data, status=200)
        except Exception as e:
            user_object = NewUser(email=email)
            user_object.save()
            print(user_object)
            user_email = user_object.email
            data = {
                "id": user_object.id,
                "email": user_email,
            }
            return JsonResponse(data, status=200)


def sendotp(email, otp):
    message = Mail(
        from_email="noreply@ripik.in",
        to_emails=email,
        subject='OTP for logging In',
        html_content=f'Your OTP for logging in is {otp}. Thank you for using our services.',
    )
    sendgrid_client = SendGridAPIClient(api_key=settings.EMAIL_HOST_PASSWORD)
    response = sendgrid_client.send(message=message)
    print(response.status_code)
    # subject = 'OTP for logging In'
    # message = f'Your OTP for logging in is {otp}. Thank you for using our services.'
    # email_from = 'noreply@ripik.in'
    # recipient_list = [email]
    # # print("email sent")
    # send_mail( subject, message, email_from, recipient_list, fail_silently=False, )


def changepassword(email, otp):
    user = NewUser.objects.all().filter(email=email).first()
    if user:
        user.set_password(otp)
        user.save()
        # print(otp)
    else:
        user = NewUser.objects.create_user(email=email, password=otp)
        print(otp)
        user.save()
    # print("passwordchanged")
    # print(user)


class UserDosageView(APIView):
    def get(self, request):
        user_id = request.query_params['id']
        dosages = DosagesNaOHRecommender.objects.all()
        serializer = DosageSerializer(dosages, many=True)
        return JsonResponse({"dosages": serializer.data}, status=200)


class MonthExportView(APIView):
    def get(self, request):
        user_id = request.query_params['id']
        today_date = date.today()
        days = today_date.day
        response = HttpResponse('')
        response['Content-Disposition'] = 'attachment; filename = dosage_all.csv'
        writer = csv.writer(response)
        writer.writerow([
            'Do_Pulp_PH_n_4',
            'NaOH_Dosage_n_3',
            'H2O2_flow_n_3',
            'VF3_Inlet_Consistency_n_3',
            'VF3_Inlet_Flow_n_3',
            'EOP_Tower_Temperature_n_3',
            'EOP_Tower_Level_n_3',
            'EOP_Viscosity_n_3',
            'EOP_Brightness_n_3',
            'EOP_Target_PH',
            'NaOH_Dosage',
            'NaOH_flow',
            'date',
            'time',
        ])
        for day in range(days):

            dosage = DosagesNaOHRecommender.objects.filter(user=user_id, date=today_date)
            today_date = today_date - timedelta(days=1)
            dosage_fields = dosage.values_list(
                'Do_Pulp_PH_n_4',
                'NaOH_Dosage_n_3',
                'H2O2_flow_n_3',
                'VF3_Inlet_Consistency_n_3',
                'VF3_Inlet_Flow_n_3',
                'EOP_Tower_Temperature_n_3',
                'EOP_Tower_Level_n_3',
                'EOP_Viscosity_n_3',
                'EOP_Brightness_n_3',
                'EOP_Target_PH',
                'NaOH_Dosage',
                'NaOH_flow',
                'date',
                'time',
            )
            for dosage in dosage_fields:
                writer.writerow(dosage)
        return response


class BetweenDateView(APIView):
    def get(self, request):
        response = HttpResponse('')
        response['Content-Disposition'] = 'attachment; filename = dosage_all.csv'
        writer = csv.writer(response)
        writer.writerow([
            'Do_Pulp_PH_n_4',
            'NaOH_Dosage_n_3',
            'H2O2_flow_n_3',
            'VF3_Inlet_Consistency_n_3',
            'VF3_Inlet_Flow_n_3',
            'EOP_Tower_Temperature_n_3',
            'EOP_Tower_Level_n_3',
            'EOP_Viscosity_n_3',
            'EOP_Brightness_n_3',
            'EOP_Target_PH',
            'NaOH_Dosage',
            'NaOH_flow',
            'date',
            'time',
        ])
        start_date = request.query_params['start_date']
        end_date = request.query_params['end_date']
        user_id = request.query_params['id']
        end_date = date(int(end_date[6:]), int(end_date[3:5]), int(end_date[0:2]))
        start_date = date(int(start_date[6:]), int(start_date[3:5]), int(start_date[0:2]))
        days = (end_date - start_date).days + 1
        initial_date = start_date

        def foo(input_date):
            input_date = str(input_date)
            print(input_date)
            dosage = DosagesNaOHRecommender.objects.all()
            dosage_fields = dosage.values_list(
                'Do_Pulp_PH_n_4',
                'NaOH_Dosage_n_3',
                'H2O2_flow_n_3',
                'VF3_Inlet_Consistency_n_3',
                'VF3_Inlet_Flow_n_3',
                'EOP_Tower_Temperature_n_3',
                'EOP_Tower_Level_n_3',
                'EOP_Viscosity_n_3',
                'EOP_Brightness_n_3',
                'EOP_Target_PH',
                'NaOH_Dosage',
                'NaOH_flow',
                'date',
                'time',
            )

            for dosage in dosage_fields:
                writer.writerow(dosage)
                # print(input_date)

        for i in range(days):
            current_date = initial_date
            foo(current_date)
            initial_date = initial_date + timedelta(days=1)
        return response

class NaOHRecommenderAuto(generics.ListAPIView):
    """
    API for fatch data form pi connector and predict 
    data from model and return recommended tmp
    """
    # Todo: Change this api coording to PI Connector
    @transaction.atomic()
    def list(self, request, *args, **kwargs):
        user = self.request.user
        newUser = NewUser.objects.filter(pk=user.pk)
        req_user = None
        if newUser.exists():
            req_user = newUser.first()            
        pi_data = get_data_from_pi()
        pi_data['Delta_target'] = pi_data['EOP_Target_PH'] - pi_data['Do_Pulp_PH_n_4']
        pi_data_copy = copy.deepcopy(pi_data)
        NaOH_conc_n_3 = pi_data['NaOH_Dosage_n_3']

        input_parameter ={
            'Eop Stage - H2O2 flow (Lag- 3 hrs) ': pi_data['H2O2_flow_n_3'],
            'Eop Stage - VF#3 inlet Consistency (Lag- 3 hrs) ': pi_data['VF3_Inlet_Consistency_n_3'],
            'Eop Stage - VF#3 inlet Flow (Lag- 3 hrs) ': pi_data['VF3_Inlet_Flow_n_3'],
            'Eop Stage - Eop Tower Temperature (Lag- 3 hrs) ': pi_data['EOP_Tower_Temperature_n_3'],
            'Eop Stage - EOP tower level (Lag- 3 hrs) ': pi_data['EOP_Tower_Level_n_3'],
            'Eop Stage - Eop viscosity (Lag- 3 hrs) ': pi_data['EOP_Viscosity_n_3'],
            'Eop Stage - Eop brightness (Lag- 3 hrs) ': pi_data['EOP_Brightness_n_3'],
            'Do stage - Do pulp pH (Lag- 4 hrs) ': pi_data['Do_Pulp_PH_n_4'],
            'Target_Eop_pulp_pH': pi_data['EOP_Target_PH'],
            'Delta_target' : pi_data['Delta_target'],
        }
        recomondations = recommend(input_parameter, NaOH_conc_n_3)

        updated_at = datetime.now().strftime("%Y-%d-%m, %I:%M:%S %p")
        pi_data_copy.update(recomondations)
        DosagesNaOHRecommender.objects.create(
            user = req_user,
            Do_Pulp_PH_n_4 = pi_data_copy['Do_Pulp_PH_n_4'],
            NaOH_Dosage_n_3 = pi_data_copy['NaOH_Dosage_n_3'],
            H2O2_flow_n_3 = pi_data_copy['H2O2_flow_n_3'],
            VF3_Inlet_Consistency_n_3 = pi_data_copy['VF3_Inlet_Consistency_n_3'],
            VF3_Inlet_Flow_n_3 = pi_data_copy['VF3_Inlet_Flow_n_3'],
            EOP_Tower_Temperature_n_3 = pi_data_copy['EOP_Tower_Temperature_n_3'],
            EOP_Tower_Level_n_3 = pi_data_copy['EOP_Tower_Level_n_3'],
            EOP_Viscosity_n_3 = pi_data_copy['EOP_Viscosity_n_3'],
            EOP_Brightness_n_3 = pi_data_copy['EOP_Brightness_n_3'],
            EOP_Target_PH = pi_data_copy['EOP_Target_PH'],
            NaOH_Dosage = pi_data_copy['NaOH_Dosage'],
            NaOH_flow = pi_data_copy['NaOH_flow']
            )

        pi_data_copy['updated_at'] = updated_at
        pi_data_copy['error sensors'] = []
        return Response(pi_data_copy)

class NaOHRecommenderCreateView(APIView):

    def post(self, request):
        D0_pulp_pH_n_4 = request.data.get('Do_Pulp_PH_n_4')
        NaOH_conc_n_3 = request.data.get('NaOH_Dosage_n_3')
        H2O2_flow_n_3 = request.data.get('H2O2_flow_n_3')
        VF3_Inlet_Consistency_n_3 = request.data.get('VF3_Inlet_Consistency_n_3')
        VF3_Inlet_Flow_n_3 = request.data.get('VF3_Inlet_Flow_n_3')
        EOP_Tower_Temperature_n_3 = request.data.get('EOP_Tower_Temperature_n_3')
        EOP_Tower_Level_n_3 = request.data.get('EOP_Tower_Level_n_3')
        EOP_Viscosity_n_3 = request.data.get('EOP_Viscosity_n_3')
        EOP_Brightness_n_3 = request.data.get('EOP_Brightness_n_3')
        Target_Eop_pulp_pH = request.data.get('EOP_Target_PH')

        input_parameter ={
            'Eop Stage - H2O2 flow (Lag- 3 hrs) ':  H2O2_flow_n_3,
            'Eop Stage - VF#3 inlet Consistency (Lag- 3 hrs) ': VF3_Inlet_Consistency_n_3,
            'Eop Stage - VF#3 inlet Flow (Lag- 3 hrs) ': VF3_Inlet_Flow_n_3,
            'Eop Stage - Eop Tower Temperature (Lag- 3 hrs) ': EOP_Tower_Temperature_n_3,
            'Eop Stage - EOP tower level (Lag- 3 hrs) ': EOP_Tower_Level_n_3,
            'Eop Stage - Eop viscosity (Lag- 3 hrs) ' :EOP_Viscosity_n_3,
            'Eop Stage - Eop brightness (Lag- 3 hrs) ' :EOP_Brightness_n_3,
            'Do stage - Do pulp pH (Lag- 4 hrs) ':D0_pulp_pH_n_4,
            'Target_Eop_pulp_pH':Target_Eop_pulp_pH,
            'Delta_target' : Target_Eop_pulp_pH-D0_pulp_pH_n_4,
        }

        response = recommend(input_parameter, NaOH_conc_n_3)

        return Response(response)