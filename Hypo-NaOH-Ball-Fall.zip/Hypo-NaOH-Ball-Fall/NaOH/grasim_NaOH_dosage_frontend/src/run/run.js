import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./run.css";
import grasim from "./images/grasin.png";
import { useNavigate } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import TextField from "@mui/material/TextField";
import Stack from "@mui/material/Stack";
import axios from "axios";
import moment from "moment";
import { Tooltip } from "@material-tailwind/react";
import {
  UPDATE_URL,
  AUTO_RUN,
  RECOMMENDER,
  RUN_INPUTS,
  BASE_API_URL,
  USER_API,
  DOSAGE_ALL_API,
  EXPORT_CSV_DAY_API,
  EXPORT_CSV_RANGE_API,
} from "../constants/api";

function Homepage1() {
  const myInterval = useRef(null);
  const [id, setData] = React.useState(
    JSON.parse(localStorage.getItem("user_id"))
  );
  const [r1, setr1] = useState(0);
  const [r2, setr2] = useState(52.8);
  const [r3, setr3] = useState(0);
  const [r4, setr4] = useState(0);
  const [r5, setr5] = useState(0);
  const [r6, setr6] = useState(0);
  const [r7, setr7] = useState(0);
  const [r8, setr8] = useState(0);
  const [r9, setr9] = useState(0);
  const [r10, setr10] = useState(11.1);
  const [r11, setr11] = useState(0);
  const [r12, setr12] = useState(0);
  const [target_loose_pulp_viscosity, setpulp] = useState("");
  const [Target_hypo_Input, sethypo] = useState("");
  const [run_button, setrun_button] = React.useState(false);
  const [hist, sethist] = React.useState(false);
  const [from, setfrom] = React.useState(
    moment(new Date()).format("YYYY-MM-DD")
  );
  const [to, setto] = React.useState(moment(new Date()).format("YYYY-MM-DD"));
  const [from1, setfrom1] = React.useState(
    moment(new Date()).format("DD-MM-YYYY")
  );
  const [to1, setto1] = React.useState(moment(new Date()).format("DD-MM-YYYY"));
  const [date, setDate] = useState(moment(new Date()).format("YYYY-MM-DD"));
  const [time, settime] = useState(new Date().toLocaleTimeString());
  const [pr, setpr] = useState("");
  const navigate = useNavigate();
  const [sheet, setData1] = useState("");
  const [data2, setData2] = useState("");
  const [active, setActive] = useState(1);

  const [hypo2, setHypo2] = useState();
  //   const [active, setActive] = useState(1);
  const [hypoAddition, setHypoAddition] = useState("");
  const [stopCalling, setStopCalling] = useState(false);
  const [timeDuration, setTimeDuration] = useState(10);
  const [updatedTime, setUpdatedTime] = useState("");
  const [updatedDate, setUpdatedDate] = useState("");
  const [recommend, setRecommend] = useState([]);

  const autoRun = async () => {
    // console.log("INSIDE AUTORUN");
    const call = await fetch(`${BASE_API_URL}/${AUTO_RUN}`, {
      method: "GET",
      // headers: {
      //     'Accept': 'application/json',
      //     'Content-Type': 'application/json',
      // },
      // body: JSON.stringify({
      //     "TRP2_outlet_consistency_2hr_lag": new Number(r1),
      //     "D0_H2SO4_flow_2hr_lag": new Number(r2),
      //     "D0_inlet_Kappa_Number_2hr_lag": new Number(r3),
      //     "Do_pH_Filtarte_2hr_lag": new Number(r4),
      //     "TRP_2_Viscosity_2hr_lag": new Number(r5),
      //     "PO2_Press_Pulp_Consistency_2hr_lag": new Number(r6),
      //     "Do_Tower_Inlet_Temperature_2hr_lag": new Number(r7),
      //     "PO_2_Press_Pulp_Flow_2hr_lag": new Number(r8),
      //     "d0_outlet_brightness": new Number(r9),
      //     "ClO2_concentration": new Number(Target_hypo_Input),
      //     "trp2_outlet_brightness": new Number(target_loose_pulp_viscosity),
      // })
    });

    const res = await call.json();

    // temp = {
    //     "EOP_viscosity_n-2": 6,
    //     "EOP_viscosity_n-1": 6,
    //     "Hypo_viscosity_n-2": 6,
    //     "Hypo_viscosity_n-1": 6,
    //     "Prev_Hypo_Addition": 6,
    //     "Target_Hypo_viscosity(previous)": 490,
    //     "Target_Loose_pulp_viscosity": 450,
    //     "Recommended_Hypo_Addition": -15.390181818181857,
    //     "Recommended_Hypo_Secondary": 0
    // }

    // "Do_Pulp_PH_n_4": Number(r1),
    // "NaOH_Dosage_n_3":Number(r2),
    // "H2O2_flow_n_3": Number(r3),
    // "VF3_Inlet_Consistency_n_3": Number(r4),
    // "VF3_Inlet_Flow_n_3": Number(r5),
    // "EOP_Tower_Temperature_n_3": Number(r6),
    // "EOP_Tower_Level_n_3": Number(r7),
    // "EOP_Viscosity_n_3": Number(r8),
    // "EOP_Brightness_n_3" : Number(r9),
    // "EOP_Target_PH" : Number(r10),
    setr1(Number(res["Do_Pulp_PH_n_4"]));
    setr2(Number(res["NaOH_Dosage_n_3"]));
    setr3(Number(res["H2O2_flow_n_3"]));
    setr4(Number(res["VF3_Inlet_Consistency_n_3"]));
    setr5(Number(res["VF3_Inlet_Flow_n_3"]));
    setr6(Number(res["EOP_Tower_Temperature_n_3"]));
    setr7(Number(res["EOP_Tower_Level_n_3"]));
    setr8(Number(res["EOP_Viscosity_n_3"]));
    setr9(Number(res["EOP_Brightness_n_3"]));
    setr10(Number(res["EOP_Target_PH"]));
    setData1(Number(res["NaOH_Dosage"]));
    setData2(Number(res["NaOH_flow"]));
    setUpdatedDate(res["updated_at"]);
    // setUpdatedTime(res["updated_time"]);

    // NaOH_Dosage: String(val1),
    //             NaOH_flow : String(val2),
    //             date: date,
    //             time: time,
    // sethypo(Number(res["Target_Hypo_viscosity(previous)"]));
    // setpulp(Number(res["Target_Loose_pulp_viscosity"]));
    // setHypoAddition(Number(res["Recommended_Hypo_Addition"])?.toFixed(2));
    // setData1((prev)=> ({...prev ,
    //     hypo_addition : res["Recommended_Hypo_Addition"].toFixed(2)}))
    // setHypo2(Number(res["Recommended_Hypo_Secondary"]));
    // setUpdatedTime(res["updated_at"])
    // setUpdatedDate(res["updated_at"].split(',')[0])
    // setRecommend(res['error sensors'])
    // setData2(res[""])
    // const val = res.success
    // setData1(res.success)
    // console.log("value", res.success)
    // if (res.success) {
    // const call = await fetch(`${BASE_API_URL}clo2_dosage/all/`, {
    //     method: "POST",
    //     headers: {
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json',
    //     },
    //     body: JSON.stringify({
    //     TRP2_outlet_consistency_2hr_lag: r1,
    //     D0_H2SO4_flow_2hr_lag: r2,
    //     D0_inlet_Kappa_Number_2hr_lag: r3,
    //     Do_pH_Filtarte_2hr_lag: r4,
    //     TRP_2_Viscosity_2hr_lag: r5,
    //     PO2_Press_Pulp_Consistency_2hr_lag: r6,
    //     Do_Tower_Inlet_Temperature_2hr_lag: r7,
    //     PO_2_Press_Pulp_Flow_2hr_lag: r8,
    //     d0_outlet_brightness: r9,
    //     ClO2_concentration: Target_hypo_Input,
    //     trp2_outlet_brightness: target_loose_pulp_viscosity,
    //     recommended_dosage: String(val),
    //     date: date,
    //     time: time,

    //     })
    // })
    // const resp = await call.json()
    // setrun_button(true)
    // axios
    //     .get(`${BASE_API_URL}/${USER_API}`, {
    //         params: {
    //             id: id
    //         }
    //     })
    //     .then((response) => {
    //         // console.log('do all =', response)
    //         setpr(response.data.dosages);
    //     })
    //     .catch((err) => console.log(err));
    // }

    // const newUser = {
    //   Target_hypo_Input: res["Target_Hypo_viscosity"],
    //   target_loose_pulp_viscosity: res["Target_Loose_pulp_viscosity"],
    //   eop_prev1: res["EOP_viscosity_n-1"],
    //   eop_prev2: res["EOP_viscosity_n-2"],
    //   hypo_add_prev1: res["Prev_Hypo_Addition"],
    //   hypo_visc_prev1: res["Hypo_viscosity_n-1"],
    //   hypo_visc_prev2: res["Hypo_viscosity_n-2"],
    //   vf6_flow: res["VF6_Flow"],
    //   user: id,
    //   target_hypo_addition: res["Recommended_Hypo_Addition"].toFixed(2),
    //   date: date,
    //   time: time,
    //   hypo2: res["Recommended_Hypo_Secondary"],
    // };
    // console.log("user", newUser);
    // console.log(date);
    // axios
    //     .post(`${BASE_API_URL}/${DOSAGE_ALL_API}`, newUser)
    //     .then((response) => {
    //     })
    //     .catch((err) => alert("There seems to be an error, kindly inform the development team"));

    setTimeout(() => {
      axios
        .get(`${BASE_API_URL}/${USER_API}`, {
          params: {
            id: id,
          },
        })
        .then((response) => {
          //   console.log("Call after run", response);
          setpr(response.data.dosages);
        })
        .catch((err) => console.log(err));
    }, 1000);
  };

  useEffect(() => {
    if (stopCalling === false) {
      //   console.log("INSIDE INTERVAL IF", stopCalling);
      myInterval.current = setInterval(() => {
        // console.log('INSIDE INTERVAL', stopCalling)
        autoRun();
      }, timeDuration * 1000);
    } else {
      //   console.log("INSIDE INTERVAL ELSE", stopCalling, intId);
      clearInterval(myInterval.current);
      myInterval.current = null;
    }
  }, [stopCalling]);

  const showInfo = async () => {
    if (run_button === false) {
      const call = await fetch(`${BASE_API_URL}/${RECOMMENDER}`, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          Do_Pulp_PH_n_4: Number(r1),
          NaOH_Dosage_n_3: Number(r2),
          H2O2_flow_n_3: Number(r3),
          VF3_Inlet_Consistency_n_3: Number(r4),
          VF3_Inlet_Flow_n_3: Number(r5),
          EOP_Tower_Temperature_n_3: Number(r6),
          EOP_Tower_Level_n_3: Number(r7),
          EOP_Viscosity_n_3: Number(r8),
          EOP_Brightness_n_3: Number(r9),
          EOP_Target_PH: Number(r10),
          // "Target_Eop_pulp_pH" : Number(r11),
          // "NaOH_conc" : Number(r12)
        }),
      });
      const res = await call.json();
      console.log("OUTPUT", res);
      const val1 = res.NaOH_Dosage;
      const val2 = res.NaOH_flow;
      setData1(res.NaOH_Dosage);
      setData2(res.NaOH_flow);
      console.log("value", res.NaOH_Dosage);
      if (res.NaOH_Dosage || res.NaOH_flow) {
        const call = await fetch(`${BASE_API_URL}/${DOSAGE_ALL_API}`, {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            Do_Pulp_PH_n_4: Number(r1),
            NaOH_Dosage_n_3: Number(r2),
            H2O2_flow_n_3: Number(r3),
            VF3_Inlet_Consistency_n_3: Number(r4),
            VF3_Inlet_Flow_n_3: Number(r5),
            EOP_Tower_Temperature_n_3: Number(r6),
            EOP_Tower_Level_n_3: Number(r7),
            EOP_Viscosity_n_3: Number(r8),
            EOP_Brightness_n_3: Number(r9),
            EOP_Target_PH: Number(r10),
            // Target_Eop_pulp_pH : Number(r11),
            // NaOH_conc : Number(r12),
            NaOH_Dosage: String(val1),
            NaOH_flow: String(val2),
            date: date,
            time: time,
          }),
        });
        const resp = await call.json();
        setrun_button(true);
        axios
          .get(`${BASE_API_URL}/${USER_API}`, {
            params: {
              id: id,
            },
          })
          .then((response) => {
            console.log("do all =", response);
            setpr(response.data.dosages);
          })
          .catch((err) => console.log(err));
      }
    } else {
      setrun_button(false);
      setr1(0);
      setr2(0);
      setr3(0);
      setpulp(0);
      sethypo(0);
      setr4(0);
      setr5(0);
      setr6(0);
      setr7(0);
      setr8(0);
      setr9(0);
      setr10(0);
      // setr11(0)
      // setr12(0)
      setData1("");
      setData2("");
    }
  };

  useEffect(() => {
    if (active === 1) {
      sethist(false);
    } else {
      sethist(true);
    }
  }, [active]);

  const handleUpdate = async () => {
    console.log("handle update");
    // const call = await fetch(`${BASE_API_URL}/${UPDATE_URL}`, {
    //   method: "POST",
    //   headers: {
    //     Accept: "application/json",
    //     "Content-Type": "application/json",
    //   },
    //   body: JSON.stringify({
    //     // "Target_Hypo_viscosity(previous)": Number(Target_hypo_Input),
    //     // Target_Loose_pulp_viscosity: Number(target_loose_pulp_viscosity),
    //   }),
    // });
    // const resp = await call.json();
    setStopCalling(false);
  };

  const handleChange1 = (event) => {
    setfrom(event.target.value);
  };
  const handleChange2 = (event) => {
    setto(event.target.value);
  };

  const handlehist1 = () => {
    if (hist === true) {
      sethist(false);
      console.log(id);
    }
    console.log(id);
  };

  const handlehist2 = () => {
    if (hist === false) {
      sethist(true);
      console.log(id);
    }
    console.log(pr);
  };

  const updater1 = (event) => {
    setr1(event.target.value);
  };

  const updater2 = (event) => {
    setr2(event.target.value);
  };

  const updater3 = (event) => {
    setr3(event.target.value);
  };

  const updater4 = (event) => {
    setr4(event.target.value);
  };

  const updater5 = (event) => {
    setr5(event.target.value);
  };
  const updater6 = (event) => {
    setr6(event.target.value);
  };
  const updater7 = (event) => {
    setr7(event.target.value);
  };
  const updater8 = (event) => {
    setr8(event.target.value);
  };
  const updater9 = (event) => {
    setr9(event.target.value);
  };
  const updater10 = (event) => {
    setr10(event.target.value);
  };
  const updateTimeDuration = (event) => {
    setTimeDuration(event.target.value);
  };
  const updater11 = (event) => {
    setr11(event.target.value);
  };
  const updater12 = (event) => {
    setr12(event.target.value);
  };

  const updatepulp = (event) => {
    setpulp(event.target.value);
  };

  const updatehypo = (event) => {
    sethypo(event.target.value);
  };
  const csvdownload = () => {
    window.location.replace(`${BASE_API_URL}/${EXPORT_CSV_DAY_API}=${1}`);
  };
  const csvdownload2 = () => {
    // window.location.replace('https://www.ripik-line-balancer-backend.com/main/export_from_to_csv/?end_date=' + to1 + '&start_date='+ from1 +'&id=' + id );
    window.location.replace(
      BASE_API_URL +
        EXPORT_CSV_RANGE_API +
        to1 +
        "&start_date=" +
        from1 +
        "&id=" +
        1
    );
  };

  useEffect(() => {
    const [year1, month1, day1] = to.split("-");
    setto1(day1 + "-" + month1 + "-" + year1);
    const [year, month, day] = from.split("-");
    setfrom1(day + "-" + month + "-" + year);
    setData(JSON.parse(localStorage.getItem("user_id")));
    setDate(moment(new Date()).format("YYYY-MM-DD"));
    settime(new Date().toLocaleTimeString());
    axios
      .get(`${BASE_API_URL}/${USER_API}`, {
        params: {
          id: id,
        },
      })
      .then((response) => {
        console.log("do all =", response);
        setpr(response.data.dosages);
      })
      .catch((err) => console.log(err));
    // console.log(pr);
  }, []);

  return (
    <>
      <div className="row r_back_img">
        <div className="flex justify-between mb-3 items-center">
          <div className="flex items-center gap-4">
            <img src={grasim} className="pl-2 pt-2 h-20 w-32"></img>
            <div className="text-2xl text-blue-500 font-bold">
              NaOH Dosage Recommender
            </div>
          </div>

          <div
            onClick={() => navigate("/")}
            className="cursor-pointer h-10 px-6 text-white pt-2 hover:bg-blue-600  rounded-md bg-blue-400 "
          >
            Logout
          </div>
        </div>

        <div className="flex justify-center mb-3">
          <div className="w-96 border rounded-full bg-blue-500 grid grid-cols-2 border-blue-500 shadow-xl">
            <div
              onClick={() => setActive(1)}
              className={
                active === 1
                  ? "flex items-center cursor-pointer justify-center items-center bg-blue-500 font-bold border-white shadow-xl text-white border border-2 rounded-l-full py-0.5"
                  : "flex items-center cursor-pointer border border-white border-2 justify-center font-bold bg-gray-300 rounded-l-full py-0.5 text-black hover:bg-blue-300"
              }
            >
              Run
            </div>
            <div
              onClick={() => setActive(2)}
              className={
                active === 2
                  ? "flex items-center cursor-pointer justify-center items-center bg-blue-500 font-bold border-white border border-2 shadow-xl text-white rounded-r-full py-0.5"
                  : "flex items-center cursor-pointer border border-white border-2 justify-center font-bold bg-gray-300 rounded-r-full py-0.5 hover:bg-blue-300"
              }
            >
              History
            </div>
          </div>
        </div>
        {/* ‘Do stage - Do pulp pH (Lag- 4 hrs) ’,
‘Eop Stage - NaOH Dosage (Lag- 3 hrs) ’,
‘Eop Stage - H2O2 flow (Lag- 3 hrs) ’,
‘Eop Stage - VF#3 inlet Consistency (Lag- 3 hrs) ’,
‘Eop Stage - VF#3 inlet Flow (Lag- 3 hrs) ’,
‘Eop Stage - Eop Tower Temperature (Lag- 3 hrs) ’,
‘Eop Stage - EOP tower level (Lag- 3 hrs) ’,
‘Eop Stage - Eop viscosity (Lag- 3 hrs) ’,
‘Eop Stage - Eop brightness (Lag- 3 hrs) ’ */}
        {hist === false && (
          <div className="row r_run_box">
            <div className="col-7">
            <div className="flex justify-between items-center px-2">
                <div className="text-blue-500 text-2xl pl-3 pt-2 pb-2">
                  Input Data{" "}
                </div>
                <div className="flex mb-3 mt-3 items-center justify-center">
                  <div className="text-blue-500 text-sm mr-2">
                    Updated at :{" "}
                  </div>
                  <div className="text-sm bg-blue-600 text-white p-2 rounded-xl font-bold">
                    {" "}
                    {updatedDate}{" "}
                  </div>
                  {/* <div className='text-blue-500 text-sm'>Updated on : {updatedDate} </div> */}
                </div>
              </div>
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">D0 - Pulp pH (Lag 1hr) :</div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r1}
                  // onChange={updater1}
                />
              </div>
              {/* {
                            "Alkcell_Cell_MD_C_n_1": 32,
                            "Alkcell_Cell_MD_D_n_1":32,
                            "Pulp_Viscosity_n_7": 450,
                            "MnSO4_n_7": 825,
                            "Mix_Charge_Quantity": 24,
                            "Jacket_WaterTemperature_C_n_1": 31,
                            "Jacket_WaterTemperature_D_n_1": 31
                        } */}
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">
                  EOP - NaOH Concentration (g/L) :
                </div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r2}
                  // onChange={updater2}
                />
              </div>
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">EOP - H2O2 flow (L/Min) :</div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r3}
                  // onChange={updater3}
                />
              </div>
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">
                  EOP - VF#3 inlet Consistency (%):
                </div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r4}
                  // onChange={updater4}
                />
              </div>
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">
                  EOP - VF#3 inlet Flow (m3/Hr):
                </div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r5}
                  // onChange={updater5}
                />
              </div>
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">
                  EOP - Tower Temperature (°C):
                </div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r6}
                  // onChange={updater6}
                />
              </div>
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">EOP - Tower level (mt):</div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r7}
                  // onChange={updater7}
                />
              </div>
              {/* Eop Stage - Eop viscosity (Lag- 3 hrs) ’,
‘Eop Stage - Eop brightness (Lag- 3 hrs) ’ */}
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">EOP - Viscosity :</div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r8}
                  // onChange={updater8}
                />
              </div>
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">EOP - brightness :</div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r9}
                  // onChange={updater9}
                />
              </div>
              <div className="row mb-0.5 flex justify-between items-center mx-2 ">
                {/* <div className='col-5 r_eop_text'> */}
                <div className="col-8 text-xl">EOP - Target pH :</div>
                <input
                  className="col-7 r_eop_box"
                  type="number"
                  value={r10}
                  // onChange={updater10}
                />
              </div>

              <div className="border border-dashed border-2 border-blue-500 mt-2 rounded-xl  pt-1 pb-1">
                <div className="row mb-1 flex justify-between items-center mx-2">
                  {/* <div className="col-7 r_eop_text">Time Duration(s):</div> */}
                  <div className="col-8 text-xl">Time interval(s):</div>
                  {/* <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r10}
                                    onChange={updater10}
                                /> */}
                  {stopCalling ? (
                    <input
                      className="col-7 r_eop_box"
                      type="number"
                      value={timeDuration}
                      onChange={updateTimeDuration}
                    />
                  ) : (
                    <input
                      className="col-7 r_eop_box"
                      type="number"
                      value={timeDuration}
                      onChange={updateTimeDuration}
                      readOnly
                    />
                  )}
                </div>
                <div className="flex justify-center items-center">
                  {stopCalling ? (
                    <div
                      onClick={handleUpdate}
                      className="rounded-lg bg-blue-500 text-white p-2 cursor-pointer font-bold"
                    >
                      {" "}
                      Update
                    </div>
                  ) : (
                    <div className="rounded-lg bg-gray-300 p-2 font-bold">
                      <Tooltip
                        animate={{
                          mount: { scale: 1, y: 0 },
                          unmount: { scale: 0, y: 0 },
                        }}
                        content="Please STOP the process before updating"
                        placement="top"
                        className="bg-blue-500 font-semibold text-3xl w-56 text-sm p-2"
                      >
                        Update
                      </Tooltip>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex justify-center items-center m-2">
                {!stopCalling ? (
                  <div
                    onClick={() => setStopCalling(true)}
                    className="bg-red-600 text-white font-bold p-2 rounded-xl cursor-pointer"
                  >
                    STOP
                  </div>
                ) : null}
              </div>

              {/* <div className='row mb-1 flex justify-between items-center mx-2 '>
                                <div className='col-8 text-xl'>
                                EOP - NaOH Concentration
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r12}
                                    onChange={updater12}
                                />
                            </div> */}
              {/* <div className='row mb-1 flex justify-between items-center mx-2 '>
                                <div className='col-8'>
                                PO 2 Press Pulp Flow 2hr lag:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="text"
                                    value={r8}
                                    onChange={updater8}
                                />
                            </div> */}
              {/* <div className='row mb-1 flex justify-between items-center mx-2 '>
                                <div className='col-8'>
                                d0 outlet brightness:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="text"
                                    value={r9}
                                    onChange={updater9}
                                />
                            </div> */}
              {/* <div className='row mb-1 flex justify-between items-center mx-2 '>
                                <div className='col-8'>
                                ClO2 concentration:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="text"
                                    value={Target_hypo_Input}
                                    onChange={updatehypo}
                                />
                            </div> */}
              {/* <div className='row mb-1 flex justify-between items-center mx-2 '>
                                <div className='col-8'>
                                trp2 outlet brightness:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="text"
                                    value={target_loose_pulp_viscosity}
                                    onChange={updatepulp}
                                />
                            </div> */}

              {/* <div className='row mb-2'>
                                <div className='col-7 r_eop_text'>
                                ClO2_concentration:
                                </div>
                                <input
                                    className='col-7 r_hypo_box'
                                    type="text"
                                    value={Target_hypo_Input}
                                    onChange={updatehypo}
                                />
                            </div> */}
              {/* <div className='row'>
                                <div className='col-7 r_eop_text'>
                                trp2_outlet_brightness:
                                </div>
                                <input
                                    className='col-7 r_hypo_box'
                                    type="text"
                                    value={target_loose_pulp_viscosity}
                                    onChange={updatepulp}
                                />
                            </div> */}
              {/* <div className='row r_run_button'>

                                {run_button === false &&
                                    <div className='r_run_button_text' onClick={() => showInfo()}><div>RUN</div></div>
                                }
                                {run_button === true &&
                                    <div className='r_run_button_text' onClick={() => showInfo()}><div>RESET</div></div>
                                }
                            </div> */}
            </div>
            <div className="col-1 vl"></div>
            <div className="col-4 inline-block">
              <div className="text-blue-500 text-3xl pl-3 ml-10 pt-3 py-3 align-top">
                Results
              </div>
              {/* {sheet &&
                                <div className=' p-2 rounded-lg m-2 flex justify-center items-center flex-col'>
                                    <div className='row r_reading_display mt-3'>
                                        <div className='r_reading_display_text'>
                                            <div>
                                                {sheet.toFixed(2)}
                                                
                                            </div>
                                        </div>
                                    </div>
                                    <div className='row text-center flex justify-center mt-4 text-xl font-bold'>
                                        NaOH dosage
                                    </div>
                                </div>
                            } */}
              {data2 && (
                <div className="flex flex-col justify-center items-center mt-16 align-middle">
                  <div className=" p-2 rounded-lg m-2 flex justify-center items-center flex-col">
                    <div className="row r_reading_display mt-3">
                      <div className="r_reading_display_text">
                        <div>
                          {data2?.toFixed(2)}
                          {/* 75 */}
                        </div>
                      </div>
                    </div>
                    <div className="row text-center flex justify-center mt-4 text-xl font-bold">
                      NaOH Flow (L/Min)
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
        {hist === true && (
          <div className="row r_run_box1 ">
            <div className="row ">
              <div className="col-3 r_run_t1">History</div>
              <div className="col-3 r_date_box">
                <Stack>
                  <TextField
                    label="FROM"
                    type="date"
                    value={from}
                    onChange={handleChange1}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </Stack>
              </div>
              <div className="col-3 r_date_box">
                <Stack>
                  <TextField
                    label="TO"
                    type="date"
                    value={to}
                    onChange={handleChange2}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                </Stack>
              </div>
              <div className="r_download_button2 pb-2">
                <div
                  className="r_run_button_text1 font-bold"
                  onClick={() => csvdownload2()}
                >
                  <div>Download</div>
                </div>
              </div>
            </div>
            <div style={{ marginTop: "-10px" }} className="row ">
              <div className="h-80 overflow-y-scroll ">
                <table>
                  <tr>
                    <th className="sticky top-0 text-center">Date</th>
                    <th className="sticky top-0 text-center">Time</th>
                    <th className="sticky top-0 text-center">
                      D0 - Pulp pH (Lag 1hrs){" "}
                    </th>
                    <th className="sticky top-0 text-center">
                      EOP - NaOH Dosage (g/L){" "}
                    </th>
                    <th className="sticky top-0 text-center">
                      EOP - H2O2 flow (L/Min)
                    </th>
                    <th className="sticky top-0 text-center">
                      EOP - VF#3 inlet Consistency (%)
                    </th>
                    <th className="sticky top-0 text-center">
                      EOP - VF#3 inlet Flow (m3/Hr)
                    </th>
                    <th className="sticky top-0 text-center">
                      EOP - Tower Temperature (°C)
                    </th>
                    <th className="sticky top-0 text-center">
                      EOP - Tower level (mt)
                    </th>
                    <th className="sticky top-0 text-center">
                      EOP - Viscosity{" "}
                    </th>
                    <th className="sticky top-0 text-center">
                      EOP - Brightness{" "}
                    </th>
                    <th className="sticky top-0 text-center">
                      EOP - Target pH
                    </th>
                    {/* <th className='sticky top-0 text-center'>EOP - Target Pulp PH</th> */}
                    {/* <th className='sticky top-0 text-center'>EOP - NaOH Concentration</th> */}
                    {/* <th className='sticky top-0 '>ClO2 concentration</th> */}
                    <th className="sticky top-0 text-center">
                      Recommended NaOH Dosage
                    </th>
                    <th className="sticky top-0 text-center">
                      Recommended NaOH Flow (L/min)
                    </th>
                  </tr>
                  {[...pr].reverse().map((val1, key) => {
                    return (
                      <tr key={key}>
                        <th className="color_back text-center">{val1.date}</th>
                        <th className="color_back text-center">
                          {val1.time.split(".")[0]}
                        </th>
                        <th className="color_back text-center">
                          {val1.Do_Pulp_PH_n_4}
                        </th>
                        <th className="color_back text-center">
                          {val1.NaOH_Dosage_n_3}
                        </th>
                        <th className="color_back text-center">
                          {val1.H2O2_flow_n_3}
                        </th>
                        <th className="color_back text-center">
                          {val1.VF3_Inlet_Consistency_n_3}
                        </th>
                        <th className="color_back text-center">
                          {val1.VF3_Inlet_Flow_n_3}
                        </th>
                        <th className="color_back text-center">
                          {val1.EOP_Tower_Temperature_n_3}
                        </th>
                        <th className="color_back text-center">
                          {val1.EOP_Tower_Level_n_3}
                        </th>
                        <th className="color_back text-center">
                          {val1.EOP_Viscosity_n_3}
                        </th>
                        <th className="color_back text-center">
                          {val1.EOP_Brightness_n_3}
                        </th>
                        <th className="color_back text-center">
                          {val1.EOP_Target_PH}
                        </th>
                        {/* <th className='color_back'>{val1.ClO2_concentration}</th> */}
                        {/* <th className='color_back'>{val1.ClO2_concentration}</th> */}
                        <th className="color_back text-center">
                          {val1.NaOH_Dosage?.toFixed(2)}
                        </th>
                        <th className="color_back text-center">
                          {val1.NaOH_flow?.toFixed(2)}
                        </th>
                      </tr>
                    );
                  })}
                </table>
              </div>
            </div>
          </div>
        )}
        <div className="row flex justify-center items-center">
          <div className="r_ripik">Powered by Ripik.ai</div>
        </div>
      </div>
    </>
  );
}

export default Homepage1;
