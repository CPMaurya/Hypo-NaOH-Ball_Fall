from django.contrib import admin
from .models import *

class DosageAdmin(admin.ModelAdmin):
    list_display = (
        'user',
        'alkcell_cell_md_c',
        'alkcell_cell_md_d',
        'pulp_viscosity',
        'MnSO4',
        'mix_charge_quantity',
        'Jacket_WaterTemperature_c',
        'Jacket_WaterTemperature_d',
        'recommended_tmp',
        'target_ball_fall',
        'date',
        'time'
    )

# Register your models here.
admin.site.register(Dosages, DosageAdmin)
admin.site.register(NewUser)