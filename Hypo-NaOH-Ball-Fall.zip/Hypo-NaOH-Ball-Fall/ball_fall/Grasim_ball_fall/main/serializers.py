from .models import *
from rest_framework import serializers


class DosageCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dosages
        fields = (
            'user', 'alkcell_cell_md_c', 'alkcell_cell_md_d', 'pulp_viscosity', 
            'MnSO4', 'mix_charge_quantity', 'Jacket_WaterTemperature_c',
            'Jacket_WaterTemperature_d', 'recommended_tmp', 
            'current_ball_fall', 'target_ball_fall')


class DosageSerializer(serializers.ModelSerializer):
    date = serializers.DateField(format="%d-%m-%y")
    class Meta:
        model = Dosages
        fields = "__all__"

    def to_representation(self, instance):
        response = super().to_representation(instance)
        response['time'] = instance.time.strftime("%H:%M:%S") if instance.time else None
        return response

class NewUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewUser
        fields = "__all__"