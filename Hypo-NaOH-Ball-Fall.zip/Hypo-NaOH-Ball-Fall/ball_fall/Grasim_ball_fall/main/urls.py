from django.urls import path, include
from .views import *

urlpatterns = [
    path('dosage/all/', DosageListView.as_view()),
    path('dosage/<int:pk>/', DosageDetailView.as_view()),
    path("export_to_csv/", ExportView.as_view()),
    path("export_to_csv_month/", MonthExportView.as_view()),
    path('login/', LoginView.as_view()),
    path('user/', UserDosageView.as_view()),
    path('export_from_to_csv/', BetweenDateView.as_view()),
    path('ball_fall_auto/', BallFallAuto.as_view(), name='ball-fall-auto'),
    path('ball_fall_recommender/', BallFallCreateView.as_view(), 
    name='ball_fall_input')
]