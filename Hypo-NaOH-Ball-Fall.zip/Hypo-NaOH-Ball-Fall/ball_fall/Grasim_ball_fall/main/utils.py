import datetime as dt
import pandas as pd
from requests_ntlm import HttpNtlmAuth
import tagreader
import numpy as np
import os
import pickle
from django.conf import settings
import xgboost as xgb

def get_data_from_pi():
    # userID='s.k'
    # userPW='9!qAtW50#'
    # tagreader.list_sources(
    #     imstype="piwebapi", 
    #     url='https://10.193.0.16/piwebapi', 
    #     verifySSL=False, 
    #     auth = HttpNtlmAuth(userID, userPW)
    # )
    
    # pi_conn = tagreader.IMSClient(
    #     datasource = 'GILVSFHRH-PI1', 
    #     imstype = 'piwebapi', 
    #     url = 'https://10.193.0.16/piwebapi',
    #     tz ='Asia/Kolkata', verifySSL=False,
    #     auth = HttpNtlmAuth(userID, userPW)
    # )
    # start_time=dt.datetime.now()-dt.timedelta(hours=2)
    # end_time_m=start_time
    # pi_conn.connect()

    # df=pi_conn.read(['F1DPsfxbRv6mI0Whd6AYjuinrQsAwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMkNP',
    #              'F1DPsfxbRv6mI0Whd6AYjuinrQWwsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDUtRklDLTE3NS1NRQ',
    #              'F1DPsfxbRv6mI0Whd6AYjuinrQtAwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMktO',
    #              'F1DPsfxbRv6mI0Whd6AYjuinrQEREAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtVkYwMi1GSUxULVBILUNUUkw',
    #              'F1DPsfxbRv6mI0Whd6AYjuinrQsQwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMlZJ',
    #              'F1DPsfxbRv6mI0Whd6AYjuinrQOgsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDQtUUlDLTcxNy1NRQ',
    #              'F1DPsfxbRv6mI0Whd6AYjuinrQXAsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDUtVEktMTMxLUFW',
    #              'F1DPsfxbRv6mI0Whd6AYjuinrQVwsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDQtRklDLTcxNC1NRQ',
    #              'F1DPsfxbRv6mI0Whd6AYjuinrQsgwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMkJS',
    #              'F1DPsfxbRv6mI0Whd6AYjuinrQdQcAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlEQ0RDU1RS'],
    #              start_time, end_time_m, 180)

    # df.rename(columns={'F1DPsfxbRv6mI0Whd6AYjuinrQsAwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMkNP':'TRP2 outlet consistency',
    #                   'F1DPsfxbRv6mI0Whd6AYjuinrQWwsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDUtRklDLTE3NS1NRQ':'D0 - H2SO4 flow',
    #                   'F1DPsfxbRv6mI0Whd6AYjuinrQtAwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMktO':'D0 inlet Kappa Number',
    #                   'F1DPsfxbRv6mI0Whd6AYjuinrQEREAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtVkYwMi1GSUxULVBILUNUUkw':'Do pH Filtarte',
    #                   'F1DPsfxbRv6mI0Whd6AYjuinrQsQwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMlZJ':'TRP 2 Viscosity',
    #                   'F1DPsfxbRv6mI0Whd6AYjuinrQOgsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDQtUUlDLTcxNy1NRQ':'PO2 Press Pulp Consistency',
    #                   'F1DPsfxbRv6mI0Whd6AYjuinrQXAsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDUtVEktMTMxLUFW':'Do Tower Inlet Temperature',
    #                   'F1DPsfxbRv6mI0Whd6AYjuinrQVwsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDQtRklDLTcxNC1NRQ':'PO-2 Press Pulp Flow',
    #                   'F1DPsfxbRv6mI0Whd6AYjuinrQsgwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMkJS':'TRP2 Outlet Brightness',
    #                   'F1DPsfxbRv6mI0Whd6AYjuinrQdQcAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlEQ0RDU1RS':'ClO2 Concentration'},
    #                   inplace=True)
    
    # df.index = pd.to_datetime( df.index, errors='coerce',utc=False)

    # response = {
    #     'TRP2_outlet_consistency_2hr_lag': df['TRP2 outlet consistency'][0],
    #     'D0_H2SO4_flow_2hr_lag': df['D0 - H2SO4 flow'][0],
    #     'D0_inlet_Kappa_Number_2hr_lag': df['D0 inlet Kappa Number'][0],
    #     'Do_pH_Filtarte_2hr_lag': df['Do pH Filtarte'][0],
    #     'TRP_2_Viscosity_2hr_lag': df['TRP 2 Viscosity'][0],
    #     'PO2_Press_Pulp_Consistency_2hr_lag': df['PO2 Press Pulp Consistency'][0],
    #     'Do_Tower_Inlet_Temperature_2hr_lag': df['Do Tower Inlet Temperature'][0],
    #     'PO_2_Press_Pulp_Flow_2hr_lag': df['PO-2 Press Pulp Flow'][0],
    #     'd0_outlet_brightness': 76,  # default
    #     'ClO2_concentration': df['ClO2 Concentration'][0],
    #     'trp2_outlet_brightness': df['TRP2 Outlet Brightness'][0]
    # }

    response = {
        'Alkcell_Cell_MD_C_n_1': 34.55,
        'Alkcell_Cell_MD_D_n_1':34.54,
        'Pulp_Viscosity_n_7': 472,
        'MnSO4_n_7': 875,
        'Mix_Charge_Quantity': 26.5,
        'Jacket_WaterTemperature_C_n_1': 41.9,
        'Jacket_WaterTemperature_D_n_1': 42.2,
        'target_ball_fall': 53,
        'current_ball_fall': 50
    }
    return response

def recommend(input_parameter):
    variables_list_by_user = [
        'Alkcell_Cell_MD_C_MD_D', 
        'Pulp_Viscosity', 'MnSO4', 
        'Mix_Charge_Quantity', 
        'Avg_Jacket_WaterTemperature']
        
    target_ball_fall = input_parameter.get('target_ball_fall', 49)
    current_ball_fall = input_parameter.get('current_ball_fall')
    prev_avg_jkt_water_tmp = input_parameter.get('Avg_Jacket_WaterTemperature')

    file_path = os.path.join(settings.BASE_DIR, 'model.json')
    # model = pickle.load(open(file_path, 'rb'))
    model = xgb.XGBRegressor()
    model.load_model(file_path)
    Avg_Jacket_WaterTemperature=np.arange(23,45,0.2)
    df11 = pd.DataFrame(columns= variables_list_by_user, index= np.arange(len(Avg_Jacket_WaterTemperature)))
    df11['Avg_Jacket_WaterTemperature'] = Avg_Jacket_WaterTemperature
    for var in variables_list_by_user:
        if var != 'Avg_Jacket_WaterTemperature':   
            df11[var] = input_parameter[var]
    user_Avg_Jacket_WaterTemperature=input_parameter['Avg_Jacket_WaterTemperature']
    X = df11.values
    a=model.predict(X)
    df11['rec_bf']=a
    df12 = df11[df11['rec_bf']== a[min(range(len(a)), key = lambda i: abs(a[i]-target_ball_fall))]] 
    delta_Avg_Jacket_WaterTemperature=user_Avg_Jacket_WaterTemperature-np.average(df12['Avg_Jacket_WaterTemperature'])
    final_recommend=user_Avg_Jacket_WaterTemperature+delta_Avg_Jacket_WaterTemperature

    if(target_ball_fall<current_ball_fall):
        # JKT has to be increased to lower the BF
        if(final_recommend<prev_avg_jkt_water_tmp):
            # 
            final_recommend+=(prev_avg_jkt_water_tmp-final_recommend)*final_recommend/prev_avg_jkt_water_tmp

    elif(target_ball_fall>current_ball_fall):
        #JKT has to be decreased to increase the BF
        if(final_recommend>prev_avg_jkt_water_tmp):
            final_recommend-=(final_recommend-prev_avg_jkt_water_tmp)*prev_avg_jkt_water_tmp/final_recommend 


    if(final_recommend<prev_avg_jkt_water_tmp-4):
        final_recommend=prev_avg_jkt_water_tmp-4

    elif(final_recommend>prev_avg_jkt_water_tmp+4):
        final_recommend=prev_avg_jkt_water_tmp+4

    return final_recommend