from django.http import JsonResponse, HttpResponse
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.permissions import *
from rest_framework.response import Response
from .serializers import *
from .models import *
from braces.views import CsrfExemptMixin
import csv
from django.contrib.auth import authenticate
from django.core.mail import send_mail
from django.conf import settings
from django.db import transaction
from datetime import date, timedelta, datetime
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail
import pandas as pd
import numpy as np
import pickle
import os
from main.utils import get_data_from_pi, recommend
import copy


class DosageDetailView(CsrfExemptMixin, generics.RetrieveUpdateDestroyAPIView):
    permission_classes = []
    serializer_class = DosageSerializer
    queryset = Dosages.objects.all()


class DosageListView(CsrfExemptMixin, generics.ListCreateAPIView):
    permission_classes = []
    serializer_class = DosageCreateSerializer
    queryset = Dosages.objects.all()

class ExportView(APIView):
    def get(self, request):
        today_date = date.today()
        user_id = request.query_params['id']
        dosage = Dosages.objects.filter(user = user_id, date = today_date)
        response = HttpResponse('')
        response['Content-Disposition'] = 'attachment; filename = dosage_all.csv'
        writer = csv.writer(response)
        writer.writerow([
            'date',
            'time',
            'Alkcell_Cell_MD_C_n-1',
            'Alkcell_Cell_MD_D_n-1',
            'Pulp_Viscosity_n-7',
            'MnSO4_n-7', 
            'Mix_Charge_Quantity', 
            'Jacket_WaterTemperature_C_n-1',
            'Jacket_WaterTemperature_D_n-1',
            'recommended_tmp',
            'target_ball_fall',
            'current_ball_fall'
        ])
        dosage_fields = dosage.values_list(
            'date',
            'time',
            'alkcell_cell_md_c',
            'alkcell_cell_md_d',
            'pulp_viscosity',
            'MnSO4',
            'mix_charge_quantity',
            'Jacket_WaterTemperature_c',
            'Jacket_WaterTemperature_d',
            'recommended_tmp',
            'target_ball_fall',
            'current_ball_fall'
        )
        for dosage in dosage_fields:
            writer.writerow(dosage)
        return response


class LoginView(APIView):
    def get(self, request):
        email = request.query_params['email']
        # print(email)
        otp = int(request.query_params['otp'])
        # print(otp)
        user = authenticate(email=email, password=otp)
        if user is not None:
            user_object = NewUser.objects.get(email=email)
            # print(user_object)
            user_id = user_object.id
            user_email = user_object.email
            data = {
                'id': user_id,
                'email': user_email,
            }
            return JsonResponse({"message": "verified", "user": data}, status=200)
        else:
            return JsonResponse({"message": "incorrect otp"}, status=200)

    def post(self, request):
        email = request.data['email']
        # def sendotpfinal(email):
        #     otp = int((random.uniform(0, 1))*100000)
        #     # print(otp)
        #     if otp <= 100000 and otp >10000:
        #         otp = f"{otp}"
        #     elif otp <= 10000 and otp >1000:
        #         otp = f"0{otp}"
        #     elif otp <= 1000 and otp >100:
        #         otp = f"00{otp}"
        #     elif otp <= 100 and otp >10:
        #         otp = f"000{otp}"
        #     elif otp <= 10 and otp >1:
        #         otp = f"0000{otp}"
        #     otp = str(otp)
        #     # print(otp)
        #     sendotp(email,otp)
        #     changepassword(email, otp)
        #     return "OTP Sent"
        # foo = sendotpfinal(email)
        try:
            user = NewUser.objects.get(email=email)
            data = {
                "id": user.id,
                "email": user.email,
            }
            return JsonResponse(data, status=200)
        except Exception as e:
            user_object = NewUser(email=email)
            user_object.save()
            # print(user_object)
            user_email = user_object.email
            data = {
                "id": user_object.id,
                "email": user_email,
            }
            return JsonResponse(data, status=200)


def sendotp(email, otp):
    message = Mail(
        from_email="noreply@ripik.in",
        to_emails=email,
        subject='OTP for logging In',
        html_content=f'Your OTP for logging in is {otp}. Thank you for using our services.',
    )
    sendgrid_client = SendGridAPIClient(api_key=settings.EMAIL_HOST_PASSWORD)
    response = sendgrid_client.send(message=message)
    # print(response.status_code)
    # subject = 'OTP for logging In'
    # message = f'Your OTP for logging in is {otp}. Thank you for using our services.'
    # email_from = 'noreply@ripik.in'
    # recipient_list = [email]
    # # print("email sent")
    # send_mail( subject, message, email_from, recipient_list, fail_silently=False, )


def changepassword(email, otp):
    user = NewUser.objects.all().filter(email=email).first()
    if user:
        user.set_password(otp)
        user.save()
        # print(otp)
    else:
        user = NewUser.objects.create_user(email=email, password=otp)
        print(otp)
        user.save()
    # print("passwordchanged")
    # print(user)


class UserDosageView(APIView):
    def get(self, request):
        user_id = request.query_params['id']
        dosages = Dosages.objects.all()
        serializer = DosageSerializer(dosages, many=True)
        return JsonResponse({"dosages": serializer.data}, status=200)


class MonthExportView(APIView):
    def get(self, request):
        user_id = request.query_params['id']
        today_date = date.today()
        days = today_date.day
        response = HttpResponse('')
        response['Content-Disposition'] = 'attachment; filename = dosage_all.csv'
        writer = csv.writer(response)
        writer.writerow([
            'date',
            'time',
            'Alkcell_Cell_MD_C_n-1',
            'Alkcell_Cell_MD_D_n-1',
            'Pulp_Viscosity_n-7',
            'MnSO4_n-7', 
            'Mix_Charge_Quantity', 
            'Jacket_WaterTemperature_C_n-1',
            'Jacket_WaterTemperature_D_n-1',
            'recommended_tmp',
            'target_ball_fall',
            'current_ball_fall'
        ])
        for day in range(days):

            dosage = Dosages.objects.filter(user=user_id, date=today_date)
            today_date = today_date - timedelta(days=1)
            dosage_fields = dosage.values_list(
                'date',
                'time',
                'alkcell_cell_md_c',
                'alkcell_cell_md_d',
                'pulp_viscosity',
                'MnSO4',
                'mix_charge_quantity',
                'Jacket_WaterTemperature_c',
                'Jacket_WaterTemperature_d',
                'recommended_tmp',
                'target_ball_fall',
                'current_ball_fall'
            )
            for dosage in dosage_fields:
                writer.writerow(dosage)
        return response


class BetweenDateView(APIView):
    def get(self, request):
        response = HttpResponse('')
        response['Content-Disposition'] = 'attachment; filename = dosage_all.csv'
        writer = csv.writer(response)
        writer.writerow([
            'date',
            'time',
            'Alkcell_Cell_MD_C_n-1',
            'Alkcell_Cell_MD_D_n-1',
            'Pulp_Viscosity_n-7',
            'MnSO4_n-7', 
            'Mix_Charge_Quantity', 
            'Jacket_WaterTemperature_C_n-1',
            'Jacket_WaterTemperature_D_n-1',
            'recommended_tmp',
            'target_ball_fall',
            'current_ball_fall'
        ])
        start_date = request.query_params['start_date']
        end_date = request.query_params['end_date']
        user_id = request.query_params['id']
        end_date = date(int(end_date[6:]), int(end_date[3:5]), int(end_date[0:2]))
        start_date = date(int(start_date[6:]), int(start_date[3:5]), int(start_date[0:2]))
        days = (end_date - start_date).days + 1
        initial_date = start_date

        def foo(input_date):
            input_date = str(input_date)
            # print(input_date)
            dosage = Dosages.objects.all()
            dosage_fields = dosage.values_list(
                'date',
                'time',
                'alkcell_cell_md_c',
                'alkcell_cell_md_d',
                'pulp_viscosity',
                'MnSO4',
                'mix_charge_quantity',
                'Jacket_WaterTemperature_c',
                'Jacket_WaterTemperature_d',
                'recommended_tmp',
                'target_ball_fall',
                'current_ball_fall'
            )

            for dosage in dosage_fields:
                writer.writerow(dosage)
                # print(input_date)

        for i in range(days):
            current_date = initial_date
            foo(current_date)
            initial_date = initial_date + timedelta(days=1)
        return response

class BallFallAuto(generics.ListAPIView):
    """
    API for fatch data form pi connector and predict 
    data from model and return recommended tmp
    """
    @transaction.atomic()
    def list(self, request, *args, **kwargs):
        user = self.request.user
        newUser = NewUser.objects.filter(pk=user.pk)
        req_user = None
        if newUser.exists():
            req_user = newUser.first()            
        pi_data = get_data_from_pi()
        input_data = {
            'Alkcell_Cell_MD_C_MD_D': sum([pi_data['Alkcell_Cell_MD_C_n_1'] + pi_data['Alkcell_Cell_MD_D_n_1']])/2,
            'Pulp_Viscosity': pi_data['Pulp_Viscosity_n_7'],
            'MnSO4': pi_data['MnSO4_n_7'],
            'Mix_Charge_Quantity': pi_data['Mix_Charge_Quantity'],
            'Avg_Jacket_WaterTemperature': sum([pi_data['Jacket_WaterTemperature_C_n_1'] + pi_data['Jacket_WaterTemperature_D_n_1']])/2,
            'target_ball_fall': pi_data['target_ball_fall'],
            'current_ball_fall': pi_data['current_ball_fall']
        }
        pi_data_copy = copy.deepcopy(pi_data)
        recomondation = recommend(input_data)
        updated_at = datetime.now().strftime("%Y-%d-%m, %I:%M:%S %p")
        pi_data_copy.update({
            "recommended_tmp": recomondation
        })
        Dosages.objects.create(
            user=req_user, 
            alkcell_cell_md_c=pi_data_copy['Alkcell_Cell_MD_C_n_1'], 
            alkcell_cell_md_d=pi_data_copy['Alkcell_Cell_MD_D_n_1'],
            pulp_viscosity=pi_data_copy['Pulp_Viscosity_n_7'], 
            MnSO4=pi_data_copy['MnSO4_n_7'], 
            mix_charge_quantity=pi_data_copy['Mix_Charge_Quantity'], 
            Jacket_WaterTemperature_c=pi_data_copy['Jacket_WaterTemperature_C_n_1'],
            Jacket_WaterTemperature_d=pi_data_copy['Jacket_WaterTemperature_D_n_1'],
            target_ball_fall= pi_data_copy['target_ball_fall'],
            current_ball_fall=pi_data_copy['current_ball_fall'],
            recommended_tmp=recomondation
        )

        pi_data_copy['updated_at'] = updated_at
        pi_data_copy['error sensors'] = []
        return Response(pi_data_copy)

class BallFallCreateView(APIView):

    def post(self, request):
        Alkcell_Cell_MD_C_n_1 = request.data.get('Alkcell_Cell_MD_C_n_1')
        Alkcell_Cell_MD_D_n_1 = request.data.get('Alkcell_Cell_MD_D_n_1')
        Pulp_Viscosity_n_7 = request.data.get('Pulp_Viscosity_n_7')
        MnSO4_n_7 = request.data.get('MnSO4_n_7')
        Mix_Charge_Quantity = request.data.get('Mix_Charge_Quantity')
        Jacket_WaterTemperature_C_n_1 = request.data.get('Jacket_WaterTemperature_C_n_1')
        Jacket_WaterTemperature_D_n_1 = request.data.get('Jacket_WaterTemperature_D_n_1')
        target_ball_fall = request.data.get('target_ball_fall')
        current_ball_fall = request.data.get('current_ball_fall')

        input_data = {
            'Alkcell_Cell_MD_C_MD_D': sum([Alkcell_Cell_MD_C_n_1 + Alkcell_Cell_MD_D_n_1])/2,
            'Pulp_Viscosity': Pulp_Viscosity_n_7,
            'MnSO4': MnSO4_n_7,
            'Mix_Charge_Quantity': Mix_Charge_Quantity,
            'Avg_Jacket_WaterTemperature': sum([Jacket_WaterTemperature_C_n_1 + Jacket_WaterTemperature_D_n_1])/2,
            'target_ball_fall': target_ball_fall,
            'current_ball_fall': current_ball_fall
        }

        recommendation = recommend(input_data)

        return Response({'recommendation': recommendation})