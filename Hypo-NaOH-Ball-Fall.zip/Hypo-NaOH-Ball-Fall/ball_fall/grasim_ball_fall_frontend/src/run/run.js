import * as React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import './run.css';
import grasim from './images/grasin.png'
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from 'react';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import axios from "axios";
import moment from 'moment';
import {RECOMMENDER, RUN_INPUTS, BASE_API_URL, USER_API, DOSAGE_ALL_API, EXPORT_CSV_DAY_API, EXPORT_CSV_RANGE_API } from '../constants/api';


function Homepage1() {
    const [id, setData] = React.useState(JSON.parse(localStorage.getItem("user_id")));
    const [r1, setr1] = useState(0);
    const [r2, setr2] = useState(0);
    const [r3, setr3] = useState(0);
    const [r4, setr4] = useState(0);
    const [r5, setr5] = useState(0);
    const [r6, setr6] = useState(0);
    const [r7, setr7] = useState(0);
    const [r8, setr8] = useState(49);
    const [r9, setr9] = useState(0);
    const [target_loose_pulp_viscosity, setpulp] = useState("");
    const [Target_hypo_Input, sethypo] = useState("");
    const [run_button, setrun_button] = React.useState(false);
    const [hist, sethist] = React.useState(false);
    const [from, setfrom] = React.useState(moment(new Date()).format("YYYY-MM-DD"));
    const [to, setto] = React.useState(moment(new Date()).format("YYYY-MM-DD"));
    const [from1, setfrom1] = React.useState(moment(new Date()).format("DD-MM-YYYY"));
    const [to1, setto1] = React.useState(moment(new Date()).format("DD-MM-YYYY"));
    const [date, setDate] = useState(moment(new Date()).format("YYYY-MM-DD"));
    const [time, settime] = useState(new Date().toLocaleTimeString());
    const [pr, setpr] = useState("");
    const navigate = useNavigate();
    const [sheet, setData1] = useState("");
    const [active, setActive] = useState(1)

    const showInfo = async () => {

        if (run_button === false) {
            const call = await fetch(`${BASE_API_URL}/${RECOMMENDER}`, {
                method: "POST",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    "Alkcell_Cell_MD_C_n_1": Number(r1),
                    "Alkcell_Cell_MD_D_n_1":Number(r2),
                    "Pulp_Viscosity_n_7": Number(r3),
                    "MnSO4_n_7": Number(r4),
                    "Mix_Charge_Quantity": Number(r5),
                    "Jacket_WaterTemperature_C_n_1": Number(r6),
                    "Jacket_WaterTemperature_D_n_1": Number(r7),
                    "target_ball_fall": Number(r8),
                    "current_ball_fall" : Number(r9)
                })
            })
            const res = await call.json()
            console.log('OUTPUT', res)
            const val = res.recommendation
            setData1(res.recommendation)
            console.log("value", res.recommendation)
            if (res.recommendation) {
                const call = await fetch(`${BASE_API_URL}/${DOSAGE_ALL_API}`, {
                    method: "POST",
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                    alkcell_cell_md_c: Number(r1),
                    alkcell_cell_md_d:Number(r2),
                    pulp_viscosity: Number(r3),
                    MnSO4: Number(r4),
                    mix_charge_quantity: Number(r5),
                    Jacket_WaterTemperature_c: Number(r6),
                    Jacket_WaterTemperature_d: Number(r7),
                    recommended_tmp: String(val),
                    target_ball_fall: Number(r8),
                    current_ball_fall : Number(r9),
                    date: date,
                    time: time,
                    })
                })
                const resp = await call.json()
                setrun_button(true)
                axios
                    .get(`${BASE_API_URL}/${USER_API}`, {
                        params: {
                            id: id
                        }
                    })
                    .then((response) => {
                        console.log('do all =', response)
                        setpr(response.data.dosages);
                    })
                    .catch((err) => console.log(err));
            }
        }

        else {
            setrun_button(false);
            setr1(0);
            setr2(0);
            setr3(0);
            setpulp(0);
            sethypo(0);
            setr4(0);
            setr5(0);
            setr6(0)
            setr7(0)
            setr8(0)
            setr9(0)
            setData1("")
        }
    }

    useEffect(() => {
        if (active === 1) {
            sethist(false)
        } else {
            sethist(true)
        }
    }, [active])

    const handleChange1 = (event) => {
        setfrom(event.target.value);

    };
    const handleChange2 = (event) => {
        setto(event.target.value);
    };

    const handlehist1 = () => {
        if (hist === true) {
            sethist(false);
            console.log(id);
        }
        console.log(id);
    };

    const handlehist2 = () => {
        if (hist === false) {
            sethist(true);
            console.log(id);
        }
        console.log(pr);
    };

    const updater1 = (event) => {
        setr1(event.target.value);
    };

    const updater2 = (event) => {
        setr2(event.target.value);
    };

    const updater3 = (event) => {
        setr3(event.target.value);
    };

    const updater4 = (event) => {
        setr4(event.target.value);
    };

    const updater5 = (event) => {
        setr5(event.target.value);
    };
    const updater6 = (event) => {
        setr6(event.target.value);
    };
    const updater7 = (event) => {
        setr7(event.target.value);
    };
    const updater8 = (event) => {
        setr8(event.target.value);
    };
    const updater9 = (event) => {
        setr9(event.target.value);
    };

    const updatepulp = (event) => {
        setpulp(event.target.value);
    };

    const updatehypo = (event) => {
        sethypo(event.target.value);
    };
    const csvdownload = () => {
        window.location.replace(`${BASE_API_URL}/${EXPORT_CSV_DAY_API}=${1}`);
    };
    const csvdownload2 = () => {
        // window.location.replace('https://www.ripik-line-balancer-backend.com/main/export_from_to_csv/?end_date=' + to1 + '&start_date='+ from1 +'&id=' + id );
        window.location.replace(BASE_API_URL + EXPORT_CSV_RANGE_API + to1 + '&start_date=' + from1 + '&id=' + 1);
    };

    useEffect(() => {
        const [year1, month1, day1] = to.split('-')
        setto1(day1 + "-" + month1 + "-" + year1);
        const [year, month, day] = from.split('-')
        setfrom1(day + "-" + month + "-" + year);
        setData(JSON.parse(localStorage.getItem("user_id")));
        setDate(moment(new Date()).format("YYYY-MM-DD"));
        settime(new Date().toLocaleTimeString());
        axios
            .get(`${BASE_API_URL}/${USER_API}`, {
                params: {
                    id: id
                }
            })
            .then((response) => {
                console.log('do all =', response)
                setpr(response.data.dosages);
            })
            .catch((err) => console.log(err));
        // console.log(pr);
    }, []);


    return (
        <>
            <div className='row r_back_img'>
                <div className='flex justify-between mb-3 items-center'>
                    <div className='flex items-center gap-4'>
                        <img src={grasim} className='pl-2 pt-2 h-20 w-32'></img>
                        <div className='text-2xl text-blue-500 font-bold'>Grasim: Ball Fall Model</div>
                    </div>

                    <div onClick={() => navigate("/")} className='cursor-pointer h-10 px-6 text-white pt-2 hover:bg-blue-600  rounded-md bg-blue-400 '>Logout</div>
                </div>

                <div className='flex justify-center mb-3'>
                    <div className='w-96 border rounded-full bg-blue-500 grid grid-cols-2 border-blue-500 shadow-xl'>
                        <div onClick={() => setActive(1)} className={active === 1 ? "flex items-center cursor-pointer justify-center items-center bg-blue-500 font-bold border-white shadow-xl text-white border border-2 rounded-l-full py-0.5" : "flex items-center cursor-pointer border border-white border-2 justify-center font-bold bg-gray-300 rounded-l-full py-0.5 text-black hover:bg-blue-300"}>Run</div>
                        <div onClick={() => setActive(2)} className={active === 2 ? "flex items-center cursor-pointer justify-center items-center bg-blue-500 font-bold border-white border border-2 shadow-xl text-white rounded-r-full py-0.5" : "flex items-center cursor-pointer border border-white border-2 justify-center font-bold bg-gray-300 rounded-r-full py-0.5 hover:bg-blue-300"}>History</div>                    
                    </div>
                </div>
                {hist === false &&
                    <div className='row r_run_box'>
                        <div className='col-7'>
                            <div className='text-blue-500 text-3xl pl-3 pt-2 pb-2 my-2'>Input Data</div>
                            <div className='row mb-2 flex justify-between items-center mx-2 '>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 text-xl'>
                                Alkcell Cell MD C :
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r1}
                                    onChange={updater1}
                                />
                            </div>
                            {/* {
    "Alkcell_Cell_MD_C_n_1": 32,
    "Alkcell_Cell_MD_D_n_1":32,
    "Pulp_Viscosity_n_7": 450,
    "MnSO4_n_7": 825,
    "Mix_Charge_Quantity": 24,
    "Jacket_WaterTemperature_C_n_1": 31,
    "Jacket_WaterTemperature_D_n_1": 31
} */}
                            <div className='row mb-2 flex justify-between items-center mx-2 '>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 text-xl'>
                                Alkcell Cell MD D :
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r2}
                                    onChange={updater2}
                                />
                            </div>
                            <div className='row mb-2 flex justify-between items-center mx-2 '>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 text-xl'>
                                Pulp Viscosity n-6:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r3}
                                    onChange={updater3}
                                />
                            </div>
                            <div className='row mb-2 flex justify-between items-center mx-2 '>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 text-xl'>
                                MnSO4 n-7:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r4}
                                    onChange={updater4}
                                />
                            </div>
                            <div className='row mb-2 flex justify-between items-center mx-2 '>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 text-xl'>
                                Mix Charge Quantity:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r5}
                                    onChange={updater5}
                                />
                            </div>
                            <div className='row mb-2 flex justify-between items-center mx-2 '>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 text-xl'>
                                Jacket WaterTemperature C n-1:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r6}
                                    onChange={updater6}
                                />
                            </div>
                            <div className='row mb-2 flex justify-between items-center mx-2 '>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 text-xl'>
                                Jacket WaterTemperature D n-1:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r7}
                                    onChange={updater7}
                                />
                            </div>
                            <div className='row mb-2 flex justify-between items-center mx-2 '>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 text-xl'>
                                Target Ball Fall:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r8}
                                    onChange={updater8}
                                />
                            </div>
                            <div className='row mb-2 flex justify-between items-center mx-2 '>
                                {/* <div className='col-5 r_eop_text'> */}
                                <div className='col-8 text-xl'>
                                Current Ball Fall:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="number"
                                    value={r9}
                                    onChange={updater9}
                                />
                            </div>
                            {/* <div className='row mb-1 flex justify-between items-center mx-2 '>
                                <div className='col-8'>
                                PO 2 Press Pulp Flow 2hr lag:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="text"
                                    value={r8}
                                    onChange={updater8}
                                />
                            </div> */}
                            {/* <div className='row mb-1 flex justify-between items-center mx-2 '>
                                <div className='col-8'>
                                d0 outlet brightness:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="text"
                                    value={r9}
                                    onChange={updater9}
                                />
                            </div> */}
                            {/* <div className='row mb-1 flex justify-between items-center mx-2 '>
                                <div className='col-8'>
                                ClO2 concentration:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="text"
                                    value={Target_hypo_Input}
                                    onChange={updatehypo}
                                />
                            </div> */}
                            {/* <div className='row mb-1 flex justify-between items-center mx-2 '>
                                <div className='col-8'>
                                trp2 outlet brightness:
                                </div>
                                <input
                                    className='col-7 r_eop_box'
                                    type="text"
                                    value={target_loose_pulp_viscosity}
                                    onChange={updatepulp}
                                />
                            </div> */}
                            
                            {/* <div className='row mb-2'>
                                <div className='col-7 r_eop_text'>
                                ClO2_concentration:
                                </div>
                                <input
                                    className='col-7 r_hypo_box'
                                    type="text"
                                    value={Target_hypo_Input}
                                    onChange={updatehypo}
                                />
                            </div> */}
                            {/* <div className='row'>
                                <div className='col-7 r_eop_text'>
                                trp2_outlet_brightness:
                                </div>
                                <input
                                    className='col-7 r_hypo_box'
                                    type="text"
                                    value={target_loose_pulp_viscosity}
                                    onChange={updatepulp}
                                />
                            </div> */}
                            <div className='row r_run_button'>

                                {run_button === false &&
                                    <div className='r_run_button_text' onClick={() => showInfo()}><div>RUN</div></div>
                                }
                                {run_button === true &&
                                    <div className='r_run_button_text' onClick={() => showInfo()}><div>RESET</div></div>
                                }
                            </div>

                        </div>
                        <div className='col-1 vl'></div>
                        <div className='col-4'>
                            <div className='text-blue-500 text-3xl pl-3 ml-10 pt-3 py-3'>Results</div>
                            {sheet &&
                                <>
                                    <div className='row r_reading_display mt-3'>
                                        <div className='r_reading_display_text'><div>{sheet.toFixed(2)}</div></div>
                                    </div>
                                    <div className='row text-center flex justify-center mt-4 text-xl font-bold'>
                                        Recommendation
                                    </div>

                                    {/*<div style={{ marginTop: '-7px' }} className='row r_download_button'>
                                        <div className='r_run_button_text' onClick={() => csvdownload()}><div>DOWNLOAD</div></div>
                            </div>*/}
                                </>
                            }
                        </div>
                    </div>
                }
                {hist === true &&
                    <div className='row r_run_box1 '>
                        <div className='row '>
                            <div className='col-3 r_run_t1'>
                                History
                            </div>
                            <div className='col-3 r_date_box'>
                                <Stack>
                                    <TextField
                                        label="FROM"
                                        type="date"
                                        value={from}
                                        onChange={handleChange1}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}

                                    />
                                </Stack>
                            </div>
                            <div className='col-3 r_date_box'>
                                <Stack>
                                    <TextField
                                        label="TO"
                                        type="date"
                                        value={to}
                                        onChange={handleChange2}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </Stack>
                            </div>
                            <div className='r_download_button2 pb-2'>
                                <div className='r_run_button_text1 font-bold' onClick={() => csvdownload2()}><div>Download</div></div>
                            </div>
                        </div>
                        <div style={{ marginTop: '-10px' }} className='row '>
                            <div className='h-80 overflow-y-scroll '>
                                <table>
                                    <tr>
                                        <th className='sticky top-0 text-center'>Date</th>
                                        <th className='sticky top-0 text-center'>Time</th>
                                        <th className='sticky top-0 text-center'>Alkcell Cell MD C </th>
                                        <th className='sticky top-0 text-center'>Alkcell Cell MD D </th>
                                        <th className='sticky top-0 text-center'>Pulp Viscosity n-6</th>
                                        <th className='sticky top-0 text-center'>MnSO4 n-7</th>
                                        <th className='sticky top-0 text-center'>Mix Charge Quantity</th>
                                        <th className='sticky top-0 text-center'>Jacket WaterTemperature C n-1</th>
                                        <th className='sticky top-0 text-center'>Jacket WaterTemperature D n-1</th>
                                        <th className='sticky top-0 text-center'>Target Ball Fall</th>
                                        <th className='sticky top-0 text-center'>Current Ball Fall</th>
                                        {/* <th className='sticky top-0 '>d0 outlet brightness</th> */}
                                        {/* <th className='sticky top-0 '>trp2 outlet brightness</th> */}
                                        {/* <th className='sticky top-0 '>ClO2 concentration</th> */}
                                        <th className='sticky top-0 text-center'>Recommendation</th>

                                    </tr>
                                    {[...pr].reverse().map((val1, key) => {
                                        return (
                                            <tr key={key}>
                                                <th className='color_back text-center'>{val1.date}</th>
                                                <th className='color_back text-center'>{val1.time.split('.')[0]}</th>
                                                <th className='color_back text-center'>{val1.alkcell_cell_md_c}</th>
                                                <th className='color_back text-center'>{val1.alkcell_cell_md_d}</th>
                                                <th className='color_back text-center'>{val1.pulp_viscosity}</th>
                                                <th className='color_back text-center'>{val1.MnSO4}</th>
                                                <th className='color_back text-center'>{val1.mix_charge_quantity}</th>
                                                <th className='color_back text-center'>{val1.Jacket_WaterTemperature_c}</th>
                                                <th className='color_back text-center'>{val1.Jacket_WaterTemperature_d}</th>
                                                <th className='color_back text-center'>{val1.target_ball_fall}</th>
                                                <th className='color_back text-center'>{val1.current_ball_fall}</th>
                                                {/* <th className='color_back'>{val1.PO_2_Press_Pulp_Flow_2hr_lag}</th>
                                                <th className='color_back'>{val1.d0_outlet_brightness}</th>
                                                <th className='color_back'>{val1.trp2_outlet_brightness}</th>
                                                <th className='color_back'>{val1.ClO2_concentration}</th> */}
                                                <th className='color_back text-center'>{val1.recommended_tmp?.toFixed(2)}</th>
                                            </tr>
                                        )
                                    })}
                                </table>
                            </div>

                        </div>

                    </div>
                }
                <div className='row flex justify-center items-center'>
                    <div className='r_ripik'>
                        Powered by Ripik.ai
                    </div>
                </div>
            </div>
        </>
    )
}

export default Homepage1;