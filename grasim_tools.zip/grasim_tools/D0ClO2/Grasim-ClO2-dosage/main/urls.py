from django.urls import path, include
from .views import *

urlpatterns = [
    path('clo2_dosage/all/', DosageListView.as_view()),
    path('clo2_dosage/<int:pk>/', DosageDetailView.as_view()),
    path("clo2_export_to_csv/", ExportView.as_view()),
    path("clo2_export_to_csv_month/", MonthExportView.as_view()),
    path('login/', LoginView.as_view()),
    path('user/', UserDosageView.as_view()),
    path('clo2_export_from_to_csv/', BetweenDateView.as_view()),
    path('run_inputs/', Brightness.as_view()),
    path('brightness_auto/', BrightnessAuto.as_view(), name='Brightness-auto'),
    path('save_default_value/', SaveDefaultValueView.as_view(), name='save-default-value')
]