import datetime as dt
import pandas as pd
from requests_ntlm import HttpNtlmAuth
import tagreader
import numpy as np
import os
import pickle
from django.conf import settings
from main.models import Dosage


def get_data_from_pi():
    userID='s.k'
    userPW='9!qAtW50#'
    tagreader.list_sources(
        imstype="piwebapi", 
        url='https://10.193.0.16/piwebapi', 
        verifySSL=False, 
        auth = HttpNtlmAuth(userID, userPW)
    )
    
    pi_conn = tagreader.IMSClient(
        datasource = 'GILVSFHRH-PI1', 
        imstype = 'piwebapi', 
        url = 'https://10.193.0.16/piwebapi',
        tz ='Asia/Kolkata', verifySSL=False,
        auth = HttpNtlmAuth(userID, userPW)
    )
    start_time=dt.datetime.now()-dt.timedelta(hours=2)
    end_time_m=start_time
    pi_conn.connect()

    df=pi_conn.read(['F1DPsfxbRv6mI0Whd6AYjuinrQsAwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMkNP',
                 'F1DPsfxbRv6mI0Whd6AYjuinrQWwsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDUtRklDLTE3NS1NRQ',
                 'F1DPsfxbRv6mI0Whd6AYjuinrQtAwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMktO',
                 'F1DPsfxbRv6mI0Whd6AYjuinrQEREAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtVkYwMi1GSUxULVBILUNUUkw',
                 'F1DPsfxbRv6mI0Whd6AYjuinrQsQwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMlZJ',
                 'F1DPsfxbRv6mI0Whd6AYjuinrQOgsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDQtUUlDLTcxNy1NRQ',
                 'F1DPsfxbRv6mI0Whd6AYjuinrQXAsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDUtVEktMTMxLUFW',
                 'F1DPsfxbRv6mI0Whd6AYjuinrQVwsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDQtRklDLTcxNC1NRQ',
                 'F1DPsfxbRv6mI0Whd6AYjuinrQsgwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMkJS',
                 'F1DPsfxbRv6mI0Whd6AYjuinrQdQcAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlEQ0RDU1RS'],
                 start_time, end_time_m, 180)

    df.rename(columns={'F1DPsfxbRv6mI0Whd6AYjuinrQsAwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMkNP':'TRP2 outlet consistency',
                      'F1DPsfxbRv6mI0Whd6AYjuinrQWwsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDUtRklDLTE3NS1NRQ':'D0 - H2SO4 flow',
                      'F1DPsfxbRv6mI0Whd6AYjuinrQtAwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMktO':'D0 inlet Kappa Number',
                      'F1DPsfxbRv6mI0Whd6AYjuinrQEREAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtVkYwMi1GSUxULVBILUNUUkw':'Do pH Filtarte',
                      'F1DPsfxbRv6mI0Whd6AYjuinrQsQwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMlZJ':'TRP 2 Viscosity',
                      'F1DPsfxbRv6mI0Whd6AYjuinrQOgsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDQtUUlDLTcxNy1NRQ':'PO2 Press Pulp Consistency',
                      'F1DPsfxbRv6mI0Whd6AYjuinrQXAsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDUtVEktMTMxLUFW':'Do Tower Inlet Temperature',
                      'F1DPsfxbRv6mI0Whd6AYjuinrQVwsAAAR0lMVlNGSFJILVBJMVxIUEYtUEktMDQtRklDLTcxNC1NRQ':'PO-2 Press Pulp Flow',
                      'F1DPsfxbRv6mI0Whd6AYjuinrQsgwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDVFJQMkJS':'TRP2 Outlet Brightness',
                      'F1DPsfxbRv6mI0Whd6AYjuinrQdQcAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlEQ0RDU1RS':'ClO2 Concentration'},
                      inplace=True)
    
    df.index = pd.to_datetime( df.index, errors='coerce',utc=False)

    response = {
        'TRP2_outlet_consistency_2hr_lag': df['TRP2 outlet consistency'][0],
        'D0_H2SO4_flow_2hr_lag': df['D0 - H2SO4 flow'][0],
        'D0_inlet_Kappa_Number_2hr_lag': df['D0 inlet Kappa Number'][0],
        'Do_pH_Filtarte_2hr_lag': df['Do pH Filtarte'][0],
        'TRP_2_Viscosity_2hr_lag': df['TRP 2 Viscosity'][0],
        'PO2_Press_Pulp_Consistency_2hr_lag': df['PO2 Press Pulp Consistency'][0],
        'Do_Tower_Inlet_Temperature_2hr_lag': df['Do Tower Inlet Temperature'][0],
        'PO_2_Press_Pulp_Flow_2hr_lag': df['PO-2 Press Pulp Flow'][0],
        'd0_outlet_brightness': 76,  # default
        'ClO2_concentration': df['ClO2 Concentration'][0],
        'trp2_outlet_brightness': df['TRP2 Outlet Brightness'][0]
    }

    # response = {
    #     'TRP2_outlet_consistency_2hr_lag': 7,
    #     'D0_H2SO4_flow_2hr_lag': 7,
    #     'D0_inlet_Kappa_Number_2hr_lag': 7,
    #     'Do_pH_Filtarte_2hr_lag': 7,
    #     'TRP_2_Viscosity_2hr_lag': 7,
    #     'PO2_Press_Pulp_Consistency_2hr_lag': 7,
    #     'Do_Tower_Inlet_Temperature_2hr_lag': 7,
    #     'PO_2_Press_Pulp_Flow_2hr_lag': 7,
    #     # 'd0_outlet_brightness': 76,  # default
    #     'ClO2_concentration': 7,
    #     'trp2_outlet_brightness': 7,
    # }
    return response

def predictions(request_data):
    Delta_Brightness = request_data['d0_outlet_brightness'] - request_data['trp2_outlet_brightness']
    ClO2_concentration = request_data['ClO2_concentration']
    min_bound = 40
    max_bound = 103.4
    ClO2_dosage = np.arange(min_bound, max_bound, 0.1)

    data = {}
    data['TRP2 outlet consistency_2hr_lag'] = request_data['TRP2_outlet_consistency_2hr_lag']
    data['D0 - H2SO4 flow_2hr_lag'] = request_data['D0_H2SO4_flow_2hr_lag']
    data['D0 inlet Kappa Number_2hr_lag'] = request_data['D0_inlet_Kappa_Number_2hr_lag']
    data['Do pH Filtarte_2hr_lag'] = request_data['Do_pH_Filtarte_2hr_lag']
    data['TRP 2 Viscosity_2hr_lag'] = request_data['TRP_2_Viscosity_2hr_lag']
    data['PO2 Press Pulp Consistency_2hr_lag'] = request_data['PO2_Press_Pulp_Consistency_2hr_lag']
    data['Do Tower Inlet Temperature_2hr_lag'] = request_data['Do_Tower_Inlet_Temperature_2hr_lag']
    data['PO-2 Press Pulp Flow_2hr_lag'] = request_data['PO_2_Press_Pulp_Flow_2hr_lag']

    df = pd.DataFrame(data, index=np.arange(len(ClO2_dosage)))
    df['D0_ClO2_Dosage_derived_2hr_lag'] = ClO2_dosage

    file_path = os.path.join(settings.BASE_DIR, 'Model.sav')
    model = pickle.load(open(file_path, 'rb'))
    df_value = df.values[:,:]
    predictions = model.predict(df_value)
    df['Delta_Target'] = abs(predictions - Delta_Brightness)
    del_index = list(df.index[df['Delta_Target'] == min(df['Delta_Target'])])[0]
    ClO2_flow = df['D0_ClO2_Dosage_derived_2hr_lag'].values[del_index]/ClO2_concentration
    return ClO2_flow

def save_data_into_db(data, user):
    Dosage.objects.create(user=user, **data)
    return
