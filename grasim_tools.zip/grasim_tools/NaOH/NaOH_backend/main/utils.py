import datetime as dt
import pandas as pd
from requests_ntlm import HttpNtlmAuth
import tagreader
import numpy as np
import os
import pickle
import xgboost as xgb
from django.conf import settings

def get_data_from_pi():
    userID='s.k'
    userPW='9!qAtW50#'
    tagreader.list_sources(
        imstype="piwebapi", 
        url='https://10.193.0.16/piwebapi', 
        verifySSL=False, 
        auth = HttpNtlmAuth(userID, userPW)
    )
    
    pi_conn = tagreader.IMSClient(
        datasource = 'GILVSFHRH-PI1', 
        imstype = 'piwebapi', 
        url = 'https://10.193.0.16/piwebapi',
        tz ='Asia/Kolkata', verifySSL=False,
        auth = HttpNtlmAuth(userID, userPW)
    )
    pi_conn.connect()

    start_time_n3=dt.datetime.now()-dt.timedelta(hours=3)
    end_time__n3=start_time_n3

    df_n3=pi_conn.read(["F1DPsfxbRv6mI0Whd6AYjuinrQEBEAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtVkYwMi1DTTAyLUgyTzItRE9TLkNPTg",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQJwwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtUUlDLTIxMy1NRQ",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQSQEAAAR0lMVlNGSFJILVBJMVxIUEYtUEktRklDLTIwNA",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQOwEAAAR0lMVlNGSFJILVBJMVxIUEYtUEktVElDLTIwMg",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQ8hAAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtVkYwMi1IWVBPMDEtTFZM",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQpgwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDRU9QVklT",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQpwwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDRU9QQlI",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQpQwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDRU9QUEg",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQegcAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlETkE1U1RS"],
                        start_time_n3, end_time__n3, 180)

    df_n3.rename(columns={"F1DPsfxbRv6mI0Whd6AYjuinrQEBEAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtVkYwMi1DTTAyLUgyTzItRE9TLkNPTg": "Eop Stage - H2O2 flow",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQJwwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtUUlDLTIxMy1NRQ": "Eop Stage - VF#3 inlet Consistency",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQSQEAAAR0lMVlNGSFJILVBJMVxIUEYtUEktRklDLTIwNA": "Eop Stage - VF#3 inlet Flow",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQOwEAAAR0lMVlNGSFJILVBJMVxIUEYtUEktVElDLTIwMg": "Eop Stage - Eop Tower Temperature",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQ8hAAAAR0lMVlNGSFJILVBJMVxIUEYtUEktQkwtVkYwMi1IWVBPMDEtTFZM": "Eop Stage - EOP tower level",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQpgwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDRU9QVklT": "Eop Stage - Eop viscosity",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQpwwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDRU9QQlI": "Eop Stage - Eop brightness",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQpQwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDRU9QUEg": "Target_Eop_pulp_pH",
                        "F1DPsfxbRv6mI0Whd6AYjuinrQegcAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlETkE1U1RS": "NaOH_Dosage_n_3"},
                      inplace=True)
    
    df_n3.index = pd.to_datetime(df_n3.index, errors='coerce',utc=False)

    start_time_n4=dt.datetime.now()-dt.timedelta(hours=4)
    end_time__n4=start_time_n4
    df_n4=pi_conn.read(["F1DPsfxbRv6mI0Whd6AYjuinrQowwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDRE9JTFBI"],
                 start_time_n4, end_time__n4, 180)

    df_n4.rename(columns={"F1DPsfxbRv6mI0Whd6AYjuinrQowwAAAR0lMVlNGSFJILVBJMVxIUEYtUEktU0FQLUlDRE9JTFBI": "Do stage - Do pulp pH",},
                      inplace=True)
    
    df_n4.index = pd.to_datetime(df_n4.index, errors='coerce',utc=False)

    response = {
        'H2O2_flow_n_3': df_n3['Eop Stage - H2O2 flow'][0],
        'VF3_Inlet_Consistency_n_3': df_n3['Eop Stage - VF#3 inlet Consistency'][0],
        'VF3_Inlet_Flow_n_3': df_n3['Eop Stage - VF#3 inlet Flow'][0],
        'EOP_Tower_Temperature_n_3': df_n3['Eop Stage - Eop Tower Temperature'][0],
        'EOP_Tower_Level_n_3': df_n3['Eop Stage - EOP tower level'][0],
        'EOP_Viscosity_n_3': df_n3['Eop Stage - Eop viscosity'][0],
        'EOP_Brightness_n_3': df_n3['Eop Stage - Eop brightness'][0],
        # 'EOP_Target_PH': df_n3['Target_Eop_pulp_pH'][0],
        'NaOH_Dosage_n_3': df_n3['NaOH_Dosage_n_3'][0],
        'Do_Pulp_PH_n_4': df_n4['Do stage - Do pulp pH'][0],  # from df_n4
    }

    # response = {
    #     'H2O2_flow_n_3': 40,
    #     'VF3_Inlet_Consistency_n_3': 40,
    #     'VF3_Inlet_Flow_n_3': 40,
    #     'EOP_Tower_Temperature_n_3': 40,
    #     'EOP_Tower_Level_n_3': 40,
    #     'EOP_Viscosity_n_3': 40,
    #     'EOP_Brightness_n_3': 40,
    #     # 'EOP_Target_PH': 40,
    #     'NaOH_Dosage_n_3': 40,
    #     'Do_Pulp_PH_n_4': 50  # from df_n4
    # }

    return response


def recommend(input_parameter, NaOH_conc_n_3):
    variables_list_by_user =[
        'Eop Stage - H2O2 flow (Lag- 3 hrs) ',
        'Eop Stage - VF#3 inlet Consistency (Lag- 3 hrs) ',
        'Eop Stage - VF#3 inlet Flow (Lag- 3 hrs) ',
        'Eop Stage - Eop Tower Temperature (Lag- 3 hrs) ',
        'Eop Stage - EOP tower level (Lag- 3 hrs) ',
        'Eop Stage - Eop viscosity (Lag- 3 hrs) ',
        'Eop Stage - Eop brightness (Lag- 3 hrs) ',
        'Do stage - Do pulp pH (Lag- 4 hrs) '
    ]
        
    file_path = os.path.join(settings.BASE_DIR, 'NaOH_model.pkl')
    model = pickle.load(open(file_path, 'rb'))
    # model = None
    # with open('/home/ripik/Downloads/NaOH_model.pkl', 'rb') as file : 
    #     model = pickle.load(file)
    min_bound = 500
    max_bound = 1500
    Eop_NaOH_Dosage = np.arange(min_bound, max_bound, 2)
    df = pd.DataFrame(columns= variables_list_by_user, index= np.arange(len(Eop_NaOH_Dosage)))
    for var in variables_list_by_user :
        if var != 'Eop_NaOH_Dosage' : 
            df.loc[:,var] = input_parameter[var]
    df.insert(0,'Eop_NaOH_Dosage',Eop_NaOH_Dosage )
    X = df.values[:,:-1]
    y_predict = model.predict(X)
    df['Delta_Target'] = abs(y_predict - input_parameter['Delta_target'])
    del_index = list(df.index[df['Delta_Target'] == min(df['Delta_Target'])])[0]
    recom = df['Eop_NaOH_Dosage'].values[del_index]
    NaOH_flow=recom/NaOH_conc_n_3

    return {'NaOH_Dosage': recom, 'NaOH_flow': NaOH_flow}